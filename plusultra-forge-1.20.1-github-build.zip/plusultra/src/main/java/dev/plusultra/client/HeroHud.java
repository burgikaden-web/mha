package dev.plusultra.client;

import dev.plusultra.data.HeroData;
import dev.plusultra.logic.AbilityManager;
import dev.plusultra.logic.Progression;
import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.Quirk;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** In-game overlay: quirk name, stamina, mastery bar, 4 ability slots with cooldowns, Plus Ultra status. */
public final class HeroHud {
    private static float shownStamina = -1f;

    private HeroHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int sw, int sh) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.player.isSpectator()) return;
        HeroData d = HeroData.get(mc.player);
        Quirk q = d.quirk();
        if (q == null) return;

        Font f = mc.font;
        int lvl = d.level();
        float max = d.maxStamina();
        if (shownStamina < 0) shownStamina = d.stamina;
        shownStamina += (d.stamina - shownStamina) * 0.25f;

        int pw = 118, ph = 80;
        int x = sw - pw - 6, y = sh - ph - 6;
        int accent = 0xFF000000 | q.color;

        // panel
        g.fill(x, y, x + pw, y + ph, 0xB00E1016);
        g.fill(x, y, x + pw, y + 2, accent);
        g.renderOutline(x, y, pw, ph, 0x40FFFFFF);

        // title row
        g.drawString(f, f.plainSubstrByWidth(q.name, 78), x + 5, y + 6, accent, true);
        String lv = "Lv " + lvl;
        g.drawString(f, lv, x + pw - 5 - f.width(lv), y + 6, 0xFFFFFFFF, true);

        // stamina
        int bx = x + 5, by = y + 19, bw = pw - 10, bh = 9;
        UiUtil.bar(g, bx, by, bw, bh, shownStamina / max, q.color);
        g.drawCenteredString(f, (int) d.stamina + "/" + (int) max, bx + bw / 2, by + 1, 0xFFFFFFFF);

        // mastery xp
        float xpRatio = 1f;
        if (lvl < HeroData.MAX_LEVEL) {
            int cur = Progression.xpToReach(lvl);
            int nxt = Progression.xpToReach(lvl + 1);
            xpRatio = (d.quirkXp() - cur) / (float) Math.max(1, nxt - cur);
        }
        UiUtil.bar(g, bx, by + bh + 3, bw, 3, xpRatio, 0xFFD43B);

        // ability slots
        int sy = y + 44;
        int sx = x + (pw - (4 * 22 + 3 * 4)) / 2;
        for (int i = 0; i < 4; i++) {
            Ability a = q.abilities.get(i);
            int ax = sx + i * 26;
            boolean locked = lvl < a.unlock;
            g.fill(ax - 1, sy - 1, ax + 23, sy + 23, locked ? 0xFF3A2020 : 0xFF000000);
            g.fill(ax, sy, ax + 22, sy + 22, 0xFF1D202A);
            g.renderItem(a.stack(), ax + 3, sy + 3);
            if (!locked && d.stamina < a.cost * (d.plusUltraActive() ? 0.5f : 1f)) g.fill(ax, sy, ax + 22, sy + 22, 0x55FF2020);
            int cd = d.cooldowns[i];
            if (cd > 0) {
                int cm = Math.max(1, d.cooldownMax[i]);
                int h = Mth.clamp((int) (22f * cd / cm), 0, 22);
                g.fill(ax, sy + 22 - h, ax + 22, sy + 22, 0xB0000000);
                g.drawCenteredString(f, String.valueOf(cd / 20 + 1), ax + 11, sy + 7, 0xFFFFFFFF);
            }
            if (locked) {
                g.fill(ax, sy, ax + 22, sy + 22, 0xC0000000);
                g.drawCenteredString(f, String.valueOf(a.unlock), ax + 11, sy + 7, 0xFFFF6B6B);
            }
            String key = Keys.ABILITY[i].getTranslatedKeyMessage().getString();
            g.drawCenteredString(f, f.plainSubstrByWidth(key, 22), ax + 11, sy + 25, locked ? 0xFF6B6F7C : 0xFFC7CCDA);
        }

        // Plus Ultra badge above the panel
        String badge = null;
        int badgeColor = 0xFFFFD43B;
        if (d.plusUltraActive()) {
            badge = "PLUS ULTRA " + (d.plusUltraTicks / 20 + 1) + "s";
            if ((mc.player.tickCount / 4) % 2 == 0) badgeColor = 0xFFFFFFFF;
        } else if (lvl >= AbilityManager.PLUS_ULTRA_LEVEL) {
            String key = Keys.PLUS_ULTRA.getTranslatedKeyMessage().getString();
            if (d.plusUltraCooldown > 0) {
                int s = d.plusUltraCooldown / 20;
                badge = "[" + key + "] Plus Ultra " + (s / 60) + ":" + String.format("%02d", s % 60);
                badgeColor = 0xFF7C86A2;
            } else {
                badge = "[" + key + "] PLUS ULTRA READY";
            }
        }
        if (badge != null) g.drawString(f, badge, x + pw - f.width(badge), y - 11, badgeColor, true);
    }
}
