package dev.plusultra.util;

import dev.plusultra.PlusUltra;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntConsumer;

/** Tiny server-thread scheduler for delayed / repeating ability effects. */
public final class Scheduler {
    private static final class Task {
        int ticks;
        final Runnable run;
        Task(int ticks, Runnable run) { this.ticks = ticks; this.run = run; }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {}

    public static void later(int ticks, Runnable r) { TASKS.add(new Task(Math.max(1, ticks), r)); }

    /** Runs {@code r} {@code times} times, first after {@code period} ticks. Argument is the iteration index. */
    public static void repeat(int period, int times, IntConsumer r) {
        for (int i = 0; i < times; i++) {
            final int idx = i;
            later(period * (i + 1), () -> r.accept(idx));
        }
    }

    public static void tick() {
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.ticks <= 0) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            try {
                t.run.run();
            } catch (Exception ex) {
                PlusUltra.LOG.error("Scheduled quirk task failed", ex);
            }
        }
    }

    public static void clear() { TASKS.clear(); }
}
