package dev.plusultra.client;

import dev.plusultra.data.HeroData;
import dev.plusultra.data.Mission;
import dev.plusultra.logic.AbilityManager;
import dev.plusultra.logic.Progression;
import dev.plusultra.network.ModNetwork;
import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.Quirks;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;

/** The Hero Menu (H): Profile, Abilities, Missions, Upgrades and Codex tabs. */
public class HeroScreen extends Screen {
    private static final int W = 344, H = 228;
    private static final String[] TABS = {"Profile", "Abilities", "Missions", "Upgrades", "Codex"};
    private static final String[] STAT_DESC = {
        "+6% ability damage per point", "+10 max stamina per point",
        "+8% stamina regeneration per point", "-2% damage taken per point"
    };
    private static int tab = 0;

    private int left, top, codexScroll;
    private HeroData d;
    private List<Component> tooltip;

    public HeroScreen() {
        super(Component.literal("Hero Menu"));
    }

    public void refresh() {
        rebuildWidgets();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        d = HeroData.get(minecraft.player);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.literal(TABS[i]), btn -> {
                tab = idx;
                rebuildWidgets();
            }).bounds(left + 6 + i * 67, top + 6, 65, 18).build();
            b.active = idx != tab;
            addRenderableWidget(b);
        }
        if (tab == 2) initMissions();
        else if (tab == 3) initUpgrades();
    }

    private void initMissions() {
        for (int i = 0; i < d.active.size(); i++) {
            final int idx = i;
            int y = top + 44 + i * 26;
            Button claim = Button.builder(Component.literal("Claim"), b -> sendMission(1, idx))
                    .bounds(left + W - 98, y + 3, 52, 18).build();
            claim.active = d.active.get(i).complete();
            addRenderableWidget(claim);
            addRenderableWidget(Button.builder(Component.literal("X"), b -> sendMission(2, idx))
                    .bounds(left + W - 42, y + 3, 20, 18).build());
        }
        for (int i = 0; i < d.offers.size(); i++) {
            final int idx = i;
            int y = top + 140 + i * 26;
            Button accept = Button.builder(Component.literal("Accept"), b -> sendMission(0, idx))
                    .bounds(left + W - 98, y + 3, 52, 18).build();
            accept.active = d.active.size() < HeroData.MAX_ACTIVE;
            addRenderableWidget(accept);
        }
        addRenderableWidget(Button.builder(Component.literal("Reroll"), b -> sendMission(3, 0))
                .bounds(left + W - 76, top + 123, 54, 14).build());
    }

    private void initUpgrades() {
        for (int i = 0; i < HeroData.STAT_NAMES.length; i++) {
            final int idx = i;
            Button plus = Button.builder(Component.literal("+"), b -> ModNetwork.CH.sendToServer(new ModNetwork.UpgradePacket(idx)))
                    .bounds(left + W - 44, top + 36 + 14 + i * 38 + 8, 24, 18).build();
            plus.active = d.skillPoints > 0 && d.stats[i] < HeroData.MAX_STAT;
            addRenderableWidget(plus);
        }
    }

    private void sendMission(int action, int index) {
        ModNetwork.CH.sendToServer(new ModNetwork.MissionPacket(action, index));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (Keys.MENU.matches(key, scan)) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (tab == 4) {
            codexScroll -= (int) Math.signum(delta);
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }

    // ================================================================== render

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Quirk q = d.quirk();
        int accent = q != null ? q.color : 0x6C7A99;

        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF05060A);
        g.fillGradient(left, top, left + W, top + H, 0xFF181B24, 0xFF0E1016);
        g.fill(left, top + 28, left + W, top + 29, 0xFF000000 | accent);

        tooltip = null;
        switch (tab) {
            case 0 -> renderProfile(g, q);
            case 1 -> renderAbilities(g, q, mx, my);
            case 2 -> renderMissions(g);
            case 3 -> renderUpgrades(g);
            default -> renderCodex(g, mx, my);
        }
        super.render(g, mx, my, pt);
        if (tooltip != null) g.renderComponentTooltip(font, tooltip, mx, my);
    }

    private void wrapped(GuiGraphics g, String text, int x, int y, int width, int color, int maxLines) {
        List<FormattedCharSequence> lines = font.split(Component.literal(text), width);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++) {
            g.drawString(font, lines.get(i), x, y + i * 10, color, false);
        }
    }

    // ------------------------------------------------------------------ profile

    private void renderProfile(GuiGraphics g, Quirk q) {
        int x = left + 10, y = top + 36;
        int rank = Progression.rank(d.heroPoints);

        UiUtil.card(g, x, y, 160, 82);
        g.drawString(font, "HERO RANK", x + 8, y + 7, 0xFF7C86A2, false);
        UiUtil.scaled(g, font, Progression.RANKS[rank], x + 8, y + 19, 1.4f, 0xFFFFD43B);
        g.drawString(font, "Hero Points: " + d.heroPoints, x + 8, y + 40, 0xFFE6E9F2, false);
        if (rank + 1 < Progression.RANKS.length) {
            int base = Progression.RANK_POINTS[rank];
            int next = Progression.RANK_POINTS[rank + 1];
            UiUtil.bar(g, x + 8, y + 54, 144, 7, (d.heroPoints - base) / (float) (next - base), 0xFFD43B);
            g.drawString(font, (next - d.heroPoints) + " pts to " + Progression.RANKS[rank + 1], x + 8, y + 66, 0xFF7C86A2, false);
        } else {
            g.drawString(font, "Maximum rank achieved!", x + 8, y + 58, 0xFF6BFF8A, false);
        }

        int rx = x + 166;
        UiUtil.card(g, rx, y, 158, 82);
        if (q == null) {
            g.drawString(font, "No Quirk", rx + 8, y + 8, 0xFFB0B7C9, true);
            wrapped(g, "Craft an Awakening Scroll (paper + diamond + XP bottle + ender pearl) and right-click it.", rx + 8, y + 24, 142, 0xFF7C86A2, 5);
        } else {
            UiUtil.scaled(g, font, q.name, rx + 8, y + 8, 1.2f, 0xFF000000 | q.color);
            g.drawString(font, q.rarity.label + " - " + q.type, rx + 8, y + 24, 0xFF000000 | q.rarity.color, false);
            wrapped(g, q.description, rx + 8, y + 38, 142, 0xFFB0B7C9, 4);
        }

        int cy = y + 88;
        UiUtil.card(g, x, cy, 324, 84);
        int lvl = d.level();
        if (q == null) {
            g.drawString(font, "Mastery: awaken a quirk to start training.", x + 8, cy + 8, 0xFF7C86A2, false);
        } else {
            g.drawString(font, "MASTERY  Lv " + lvl + " - " + Progression.masteryTitle(lvl), x + 8, cy + 8, 0xFFFFFFFF, true);
            int cur = Progression.xpToReach(lvl);
            int nxt = lvl >= HeroData.MAX_LEVEL ? cur : Progression.xpToReach(lvl + 1);
            float ratio = lvl >= HeroData.MAX_LEVEL ? 1f : (d.quirkXp() - cur) / (float) Math.max(1, nxt - cur);
            UiUtil.bar(g, x + 8, cy + 22, 308, 8, ratio, q.color);
            String xp = lvl >= HeroData.MAX_LEVEL ? "MAX LEVEL" : (d.quirkXp() - cur) + " / " + (nxt - cur) + " XP";
            g.drawCenteredString(font, xp, x + 162, cy + 33, 0xFFC7CCDA);
        }
        String[] labels = {"Missions", "Ability Casts", "Mobs Defeated", "Skill Points"};
        int[] values = {d.missionsCompleted, d.totalCasts, d.totalKills, d.skillPoints};
        for (int i = 0; i < 4; i++) {
            int sx = x + 8 + i * 78;
            g.drawString(font, String.valueOf(values[i]), sx, cy + 50, 0xFFFFD43B, true);
            g.drawString(font, labels[i], sx, cy + 62, 0xFF7C86A2, false);
        }
        String pu;
        int puColor;
        if (q == null || lvl < AbilityManager.PLUS_ULTRA_LEVEL) { pu = "Plus Ultra: Lv " + AbilityManager.PLUS_ULTRA_LEVEL; puColor = 0xFF6B6F7C; }
        else if (d.plusUltraActive()) { pu = "PLUS ULTRA ACTIVE"; puColor = 0xFFFFD43B; }
        else if (d.plusUltraCooldown > 0) { pu = "Plus Ultra " + (d.plusUltraCooldown / 20) + "s"; puColor = 0xFF7C86A2; }
        else { pu = "Plus Ultra READY"; puColor = 0xFF6BFF8A; }
        g.drawString(font, pu, x + 324 - 8 - font.width(pu), cy + 50, puColor, true);
    }

    // ------------------------------------------------------------------ abilities

    private void renderAbilities(GuiGraphics g, Quirk q, int mx, int my) {
        int x = left + 10, y = top + 36;
        if (q == null) {
            g.drawCenteredString(font, "You have no quirk yet.", left + W / 2, top + 110, 0xFFB0B7C9);
            return;
        }
        int lvl = d.level();
        for (int i = 0; i < q.abilities.size(); i++) {
            Ability a = q.abilities.get(i);
            int ry = y + i * 46;
            UiUtil.card(g, x, ry, 324, 42);
            g.fill(x, ry, x + 3, ry + 42, 0xFF000000 | q.color);
            g.fill(x + 10, ry + 9, x + 34, ry + 33, 0xFF0D0F14);
            g.renderItem(a.stack(), x + 14, ry + 13);
            g.drawString(font, a.name, x + 42, ry + 6, 0xFFFFFFFF, true);
            wrapped(g, a.desc, x + 42, ry + 18, 190, 0xFF9AA3B8, 2);
            String key = "[" + Keys.ABILITY[i].getTranslatedKeyMessage().getString() + "]";
            g.drawString(font, key, x + 316 - font.width(key), ry + 6, 0xFFFFD43B, false);
            String st = a.cost + " stamina | " + (a.cooldown / 20) + "s CD";
            g.drawString(font, st, x + 316 - font.width(st), ry + 18, 0xFF7EC8FF, false);
            if (lvl < a.unlock) {
                g.fill(x, ry, x + 324, ry + 42, 0xB0000000);
                g.drawCenteredString(font, "LOCKED - reach mastery level " + a.unlock, x + 162, ry + 17, 0xFFFF6B6B);
            }
        }
    }

    // ------------------------------------------------------------------ missions

    private void renderMissions(GuiGraphics g) {
        int x = left + 10;
        g.drawString(font, "ACTIVE MISSIONS (" + d.active.size() + "/" + HeroData.MAX_ACTIVE + ")", x, top + 34, 0xFF7C86A2, false);
        for (int i = 0; i < HeroData.MAX_ACTIVE; i++) {
            int ry = top + 44 + i * 26;
            UiUtil.card(g, x, ry, 324, 24);
            if (i < d.active.size()) missionRow(g, d.active.get(i), x, ry, true);
            else g.drawString(font, "Empty slot - accept a mission below", x + 8, ry + 8, 0xFF4E566E, false);
        }
        g.drawString(font, "AVAILABLE MISSIONS", x, top + 127, 0xFF7C86A2, false);
        for (int i = 0; i < d.offers.size(); i++) {
            int ry = top + 140 + i * 26;
            UiUtil.card(g, x, ry, 324, 24);
            missionRow(g, d.offers.get(i), x, ry, false);
        }
    }

    private void missionRow(GuiGraphics g, Mission m, int x, int y, boolean active) {
        int tw = 206;
        String title = m.type.title + "  " + "*".repeat(m.tier + 1);
        g.drawString(font, title, x + 8, y + 3, active && m.complete() ? 0xFF6BFF8A : 0xFFFFFFFF, false);
        g.drawString(font, font.plainSubstrByWidth(m.description(), tw - 40), x + 8, y + 13, 0xFF9AA3B8, false);
        String rw = "+" + m.points + " pts  +" + m.xp + " xp";
        g.drawString(font, rw, x + tw - font.width(rw), y + 3, 0xFFFFD43B, false);
        if (active) {
            String pr = m.progress + "/" + m.target;
            g.drawString(font, pr, x + tw - font.width(pr), y + 13, m.complete() ? 0xFF6BFF8A : 0xFFC7CCDA, false);
            UiUtil.bar(g, x + 8, y + 21, tw - 8, 2, m.progress / (float) m.target, m.complete() ? 0x6BFF8A : 0x4DA3FF);
        }
    }

    // ------------------------------------------------------------------ upgrades

    private void renderUpgrades(GuiGraphics g) {
        int x = left + 10, y = top + 36;
        g.drawString(font, "Skill Points: " + d.skillPoints, x, y, 0xFFFFD43B, true);
        g.drawString(font, "+1 skill point per mastery level", x + 110, y, 0xFF7C86A2, false);
        for (int i = 0; i < HeroData.STAT_NAMES.length; i++) {
            int ry = y + 14 + i * 38;
            UiUtil.card(g, x, ry, 324, 34);
            g.drawString(font, HeroData.STAT_NAMES[i], x + 8, ry + 5, 0xFFFFFFFF, true);
            g.drawString(font, STAT_DESC[i], x + 8, ry + 16, 0xFF9AA3B8, false);
            for (int k = 0; k < HeroData.MAX_STAT; k++) {
                g.fill(x + 8 + k * 16, ry + 26, x + 8 + k * 16 + 14, ry + 30, k < d.stats[i] ? 0xFFFFD43B : 0xFF2B3040);
            }
            String v = d.stats[i] + "/" + HeroData.MAX_STAT;
            g.drawString(font, v, x + 316 - 40 - font.width(v), ry + 5, 0xFFC7CCDA, false);
        }
    }

    // ------------------------------------------------------------------ codex

    private void renderCodex(GuiGraphics g, int mx, int my) {
        List<Quirk> all = new ArrayList<>(Quirks.all());
        int x = left + 10, y = top + 36, rowH = 30, visible = 6;
        codexScroll = Mth.clamp(codexScroll, 0, Math.max(0, all.size() - visible));
        for (int i = 0; i < visible; i++) {
            int idx = codexScroll + i;
            if (idx >= all.size()) break;
            Quirk q = all.get(idx);
            int ry = y + i * rowH;
            UiUtil.card(g, x, ry, 310, 28);
            g.fill(x, ry, x + 3, ry + 28, 0xFF000000 | q.rarity.color);
            g.renderItem(q.abilities.get(0).stack(), x + 8, ry + 6);
            boolean equipped = q.id.equals(d.quirkId);
            g.drawString(font, (equipped ? "> " : "") + q.name, x + 30, ry + 5, 0xFF000000 | q.color, true);
            g.drawString(font, q.rarity.label + " " + q.type, x + 30, ry + 16, 0xFF000000 | q.rarity.color, false);
            int lvl = d.levelOf(q.id);
            boolean trained = d.xp.containsKey(q.id);
            String s = trained ? "Mastery Lv " + lvl : "Undiscovered";
            g.drawString(font, s, x + 302 - font.width(s), ry + 10, trained ? 0xFFFFD43B : 0xFF4E566E, false);
            if (mx >= x && mx < x + 310 && my >= ry && my < ry + 28) {
                List<Component> tip = new ArrayList<>();
                tip.add(Component.literal(q.name).withStyle(ChatFormatting.BOLD));
                tip.add(Component.literal(q.description).withStyle(ChatFormatting.GRAY));
                for (Ability a : q.abilities) {
                    tip.add(Component.literal(" - " + a.name + " (Lv " + a.unlock + ")").withStyle(ChatFormatting.YELLOW));
                }
                tooltip = tip;
            }
        }
        if (all.size() > visible) {
            int trackH = visible * rowH - 2;
            int thumbH = Math.max(14, trackH * visible / all.size());
            int thumbY = y + (trackH - thumbH) * codexScroll / (all.size() - visible);
            g.fill(x + 314, y, x + 318, y + trackH, 0xFF0D0F14);
            g.fill(x + 314, thumbY, x + 318, thumbY + thumbH, 0xFF6C7A99);
        }
    }
}
