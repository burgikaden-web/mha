package dev.plusultra.quirk.impl;

import static dev.plusultra.util.Fx.*;

import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.QuirkRarity;
import dev.plusultra.util.Scheduler;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/** Zero Gravity, Warp Gate, Fierce Wings, Frog. */
public final class MobilityQuirks {
    private MobilityQuirks() {}

    public static Quirk zeroGravity() {
        return new Quirk("zero_gravity", "Zero Gravity", "Emitter",
            "Nullify gravity on anything you touch. Float your foes, then bring the sky down on them.",
            QuirkRarity.RARE, 0xF78FB3,
            (p, lvl) -> { if (lvl >= 10) buff(p, MobEffects.SLOW_FALLING, 60, 0); },
            new Ability("Zero Gravity Touch", Items.PHANTOM_MEMBRANE, 1, 15, 100,
                "Make a nearby target weightless and helpless.", c -> {
                    LivingEntity t = target(c.player(), 5);
                    if (t == null) return false;
                    debuff(t, MobEffects.LEVITATION, 100, 0);
                    c.level().sendParticles(ParticleTypes.END_ROD, center(t).x, center(t).y, center(t).z, 25, 0.4, 0.6, 0.4, 0.05);
                    sound(c.level(), center(t), SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 0.6f);
                    return true;
                }),
            new Ability("Float", Items.FEATHER, 4, 25, 400,
                "Lighten yourself: a soaring hop, slow falling and extra jump height.", c -> {
                    ServerPlayer p = c.player();
                    push(p, p.getDeltaMovement().add(0, 1.0, 0));
                    buff(p, MobEffects.SLOW_FALLING, 600, 0);
                    buff(p, MobEffects.JUMP, 600, 1);
                    ring(c.level(), ParticleTypes.END_ROD, p.position().add(0, 0.2, 0), 1.0, 16);
                    sound(c.level(), p.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.2f, 1.2f);
                    return true;
                }),
            new Ability("Meteor Shower", Items.AMETHYST_SHARD, 8, 40, 600,
                "Float everyone around the target, then slam them back to the ground.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 at = aim(p, 18);
                    List<LivingEntity> victims = near(p, at, 9);
                    if (victims.isEmpty()) return false;
                    for (LivingEntity e : victims) {
                        debuff(e, MobEffects.LEVITATION, 60, 1);
                        c.level().sendParticles(ParticleTypes.END_ROD, center(e).x, center(e).y, center(e).z, 15, 0.3, 0.5, 0.3, 0.05);
                    }
                    float dmg = c.dmg(8);
                    Scheduler.later(60, () -> {
                        for (LivingEntity e : victims) {
                            if (!e.isAlive()) continue;
                            e.removeEffect(MobEffects.LEVITATION);
                            push(e, new Vec3(0, -2.5, 0));
                            hit(p, e, dmg);
                            c.level().sendParticles(ParticleTypes.EXPLOSION, e.getX(), e.getY(), e.getZ(), 1, 0, 0, 0, 0);
                        }
                        sound(c.level(), at, SoundEvents.GENERIC_EXPLODE, 1f, 1.2f);
                    });
                    sound(c.level(), at, SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 0.5f);
                    return true;
                }),
            new Ability("Comet Home", Items.END_CRYSTAL, 13, 60, 1000,
                "Call down a barrage of 14 meteors over the target area.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 at = aim(p, 25);
                    float dmg = c.dmg(12);
                    Scheduler.repeat(4, 14, i -> {
                        if (!p.isAlive()) return;
                        Vec3 spot = randomSpot(c.level(), at, 0, 10);
                        Vec3 top = spot.add(0, 25, 0);
                        line(c.level(), ParticleTypes.FLAME, top, spot, 1.0);
                        blast(p, spot, 3.2f, dmg, 1.2);
                    });
                    sound(c.level(), p.position(), SoundEvents.ENDER_DRAGON_GROWL, 1f, 1.4f);
                    return true;
                }));
    }

    public static Quirk warpGate() {
        return new Quirk("warp_gate", "Warp Gate", "Emitter",
            "Open gates through space. Move yourself - or your enemies - anywhere.",
            QuirkRarity.EPIC, 0x8E5CF5,
            null,
            new Ability("Warp Step", Items.ENDER_PEARL, 1, 15, 60,
                "Step through a gate to the point you are looking at (up to 14 blocks).", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.position();
                    Vec3 to = aim(p, 14).subtract(c.look().scale(0.6));
                    Vec3 dest = new Vec3(to.x, to.y - p.getEyeHeight(), to.z);
                    for (int i = 0; i < 8; i++) {
                        if (!solid(c.level(), dest.add(0, 0.1, 0)) && !solid(c.level(), dest.add(0, 1.7, 0))) break;
                        dest = dest.add(0, 0.5, 0);
                    }
                    c.level().sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.5);
                    tp(p, dest);
                    c.level().sendParticles(ParticleTypes.PORTAL, dest.x, dest.y + 1, dest.z, 40, 0.4, 0.8, 0.4, 0.5);
                    sound(c.level(), dest, SoundEvents.ENDERMAN_TELEPORT, 1f, 1.1f);
                    return from.distanceTo(dest) > 1;
                }),
            new Ability("Gate Swap", Items.ENDER_EYE, 4, 25, 200,
                "Instantly trade places with the target in your line of sight.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity t = target(p, 16);
                    if (t == null) return false;
                    Vec3 a = p.position();
                    Vec3 b = t.position();
                    tp(t, a);
                    tp(p, b);
                    c.level().sendParticles(ParticleTypes.REVERSE_PORTAL, a.x, a.y + 1, a.z, 30, 0.4, 0.8, 0.4, 0.2);
                    c.level().sendParticles(ParticleTypes.REVERSE_PORTAL, b.x, b.y + 1, b.z, 30, 0.4, 0.8, 0.4, 0.2);
                    sound(c.level(), b, SoundEvents.ENDERMAN_TELEPORT, 1f, 0.8f);
                    return true;
                }),
            new Ability("Banish Gate", Items.CHORUS_FRUIT, 8, 35, 400,
                "Fling a single target through a gate to somewhere far away.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity t = target(p, 14);
                    if (t == null) return false;
                    Vec3 spot = randomSpot(c.level(), t.position(), 20, 28);
                    c.level().sendParticles(ParticleTypes.PORTAL, t.getX(), t.getY() + 1, t.getZ(), 50, 0.4, 0.8, 0.4, 0.5);
                    tp(t, spot);
                    hit(p, t, c.dmg(4));
                    debuff(t, MobEffects.MOVEMENT_SLOWDOWN, 60, 1);
                    sound(c.level(), spot, SoundEvents.ENDERMAN_TELEPORT, 1f, 0.6f);
                    return true;
                }),
            new Ability("Warp Barrage", Items.END_PORTAL_FRAME, 13, 60, 900,
                "Open gates under every enemy in range and scatter them across the map.", c -> {
                    ServerPlayer p = c.player();
                    List<LivingEntity> targets = new ArrayList<>(near(p, p.position().add(0, 1, 0), 10));
                    if (targets.isEmpty()) return false;
                    for (LivingEntity e : targets) {
                        c.level().sendParticles(ParticleTypes.PORTAL, e.getX(), e.getY() + 1, e.getZ(), 40, 0.4, 0.8, 0.4, 0.5);
                        tp(e, randomSpot(c.level(), e.position(), 15, 30));
                        hit(p, e, c.dmg(6));
                    }
                    buff(p, MobEffects.MOVEMENT_SPEED, 100, 1);
                    sound(c.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 1.5f, 0.5f);
                    return true;
                }));
    }

    public static Quirk fierceWings() {
        return new Quirk("fierce_wings", "Fierce Wings", "Mutant",
            "Crimson wings with hundreds of razor feathers. Fast, deadly, and airborne.",
            QuirkRarity.EPIC, 0xD63031,
            (p, lvl) -> { if (lvl >= 8) buff(p, MobEffects.SLOW_FALLING, 60, 0); },
            new Ability("Feather Volley", Items.FEATHER, 1, 14, 40,
                "Fire a fan of five razor feathers at your target.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.getEyePosition().subtract(0, 0.2, 0);
                    for (int i = -2; i <= 2; i++) {
                        Vec3 dir = c.look().yRot((float) Math.toRadians(i * 6.0));
                        line(c.level(), dust(0xD63031, 0.9f), from, from.add(dir.scale(18)), 0.7);
                        LivingEntity t = target(p, from, dir, 18);
                        if (t != null) hit(p, t, c.dmg(4));
                    }
                    sound(c.level(), p.position(), SoundEvents.ARROW_SHOOT, 1f, 1.8f);
                    return true;
                }),
            new Ability("Wing Dash", Items.ARROW, 4, 20, 120,
                "Beat your wings for a rapid, slicing dash.", c -> {
                    dashAttack(c, 2.0, 0.4, 8, 2.0, c.dmg(4), 0.6, dust(0xD63031, 1.0f));
                    sound(c.level(), c.player().position(), SoundEvents.ENDER_DRAGON_FLAP, 1f, 1.4f);
                    return true;
                }),
            new Ability("Storm of Feathers", Items.SPECTRAL_ARROW, 8, 40, 500,
                "A 3-second whirlwind of feathers that shreds up to three enemies each pulse.", c -> {
                    ServerPlayer p = c.player();
                    float dmg = c.dmg(4);
                    Scheduler.repeat(5, 12, i -> {
                        if (!p.isAlive()) return;
                        Vec3 ctr = p.position().add(0, 1, 0);
                        ring(c.level(), dust(0xD63031, 1.1f), ctr, 2.5 + (i % 3), 18);
                        List<LivingEntity> list = near(p, ctr, 9);
                        for (int k = 0; k < Math.min(3, list.size()); k++) {
                            LivingEntity e = list.get(p.getRandom().nextInt(list.size()));
                            line(c.level(), dust(0xD63031, 0.9f), ctr, center(e), 0.6);
                            hit(p, e, dmg);
                        }
                    });
                    sound(c.level(), p.position(), SoundEvents.ENDER_DRAGON_FLAP, 1.3f, 1.8f);
                    return true;
                }),
            new Ability("Wings Unleashed", Items.ELYTRA, 13, 55, 1200,
                "True flight for 15 seconds.", c -> {
                    ServerPlayer p = c.player();
                    if (c.data().flightTicks > 0) return false;
                    c.data().flightTicks = 300;
                    setFlight(p, true);
                    push(p, p.getDeltaMovement().add(0, 0.8, 0));
                    ring(c.level(), dust(0xD63031, 1.4f), p.position().add(0, 1, 0), 1.5, 24);
                    sound(c.level(), p.position(), SoundEvents.ENDER_DRAGON_FLAP, 1.5f, 0.9f);
                    return true;
                }));
    }

    public static Quirk frog() {
        return new Quirk("frog", "Frog", "Mutant",
            "Leap, swim and lash out with a long, sticky tongue. Ribbit.",
            QuirkRarity.COMMON, 0x55E6C1,
            (p, lvl) -> {
                if (p.isInWater()) {
                    buff(p, MobEffects.DOLPHINS_GRACE, 60, 0);
                    if (lvl >= 5) buff(p, MobEffects.WATER_BREATHING, 60, 0);
                }
                if (lvl >= 8) buff(p, MobEffects.JUMP, 60, 0);
            },
            new Ability("Tongue Lash", Items.SLIME_BALL, 1, 10, 40,
                "Lash out with your tongue and yank a target toward you.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity t = target(p, 12);
                    if (t == null) return false;
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), dust(0xFF6B81, 1.0f), from, center(t), 0.35);
                    Vec3 pull = p.position().subtract(t.position()).normalize().scale(1.4);
                    push(t, new Vec3(pull.x, 0.25, pull.z));
                    hit(p, t, c.dmg(4));
                    sound(c.level(), p.position(), SoundEvents.FROG_TONGUE, 1.2f, 1f);
                    return true;
                }),
            new Ability("Frog Leap", Items.RABBIT_FOOT, 4, 15, 80,
                "A huge leap forward. You take no fall damage while leaping.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 look = c.look();
                    push(p, new Vec3(look.x * 1.5, Mth.clamp(look.y * 1.2 + 0.9, 0.7, 1.6), look.z * 1.5));
                    p.fallDistance = 0;
                    Scheduler.repeat(2, 25, i -> { if (p.isAlive()) p.fallDistance = 0; });
                    sound(c.level(), p.position(), SoundEvents.FROG_LONG_JUMP, 1.3f, 1f);
                    return true;
                }),
            new Ability("Acid Spit", Items.FERMENTED_SPIDER_EYE, 8, 28, 140,
                "Spit corrosive acid at a distant target.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity t = target(p, 14);
                    if (t == null) return false;
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), dust(0x7CFC00, 1.2f), from, center(t), 0.4);
                    hit(p, t, c.dmg(5));
                    debuff(t, MobEffects.POISON, 100, 1);
                    debuff(t, MobEffects.MOVEMENT_SLOWDOWN, 60, 0);
                    sound(c.level(), p.position(), SoundEvents.LLAMA_SPIT, 1.2f, 0.8f);
                    return true;
                }),
            new Ability("Frog Frenzy", Items.LILY_PAD, 13, 50, 900,
                "Go wild for 12 seconds: super speed, leaping and a bouncing pummel aura.", c -> {
                    ServerPlayer p = c.player();
                    buff(p, MobEffects.JUMP, 240, 3);
                    buff(p, MobEffects.MOVEMENT_SPEED, 240, 2);
                    buff(p, MobEffects.DOLPHINS_GRACE, 240, 0);
                    buff(p, MobEffects.WATER_BREATHING, 300, 0);
                    float dmg = c.dmg(4);
                    Scheduler.repeat(10, 24, i -> {
                        if (!p.isAlive()) return;
                        for (LivingEntity e : near(p, p.position().add(0, 1, 0), 3.5)) {
                            hit(p, e, dmg);
                            knock(e, p.position(), 0.5, 0.3);
                        }
                    });
                    ring(c.level(), dust(0x55E6C1, 1.4f), p.position().add(0, 0.2, 0), 1.5, 24);
                    sound(c.level(), p.position(), SoundEvents.FROG_LONG_JUMP, 1.5f, 0.7f);
                    return true;
                }));
    }
}
