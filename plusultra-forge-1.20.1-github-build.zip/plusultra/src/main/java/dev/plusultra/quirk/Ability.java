package dev.plusultra.quirk;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class Ability {
    /** Returns true if the ability actually fired (cost + cooldown are only charged then). */
    @FunctionalInterface
    public interface Effect {
        boolean cast(AbilityContext ctx);
    }

    public final String name;
    public final String desc;
    public final Item icon;
    public final int unlock;
    public final int cost;
    public final int cooldown;
    public final Effect effect;
    private ItemStack stack;

    public Ability(String name, Item icon, int unlock, int cost, int cooldown, String desc, Effect effect) {
        this.name = name;
        this.icon = icon;
        this.unlock = unlock;
        this.cost = cost;
        this.cooldown = cooldown;
        this.desc = desc;
        this.effect = effect;
    }

    /** Client-side helper for drawing the icon. */
    public ItemStack stack() {
        if (stack == null) stack = new ItemStack(icon);
        return stack;
    }
}
