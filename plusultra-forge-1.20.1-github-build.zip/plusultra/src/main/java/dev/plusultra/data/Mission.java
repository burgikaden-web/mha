package dev.plusultra.data;

import net.minecraft.nbt.CompoundTag;

public class Mission {
    public enum Type {
        KILL_ANY("Street Patrol", "Defeat %d hostile mobs"),
        KILL_ZOMBIE("Undead Cleanup", "Defeat %d zombies"),
        KILL_SKELETON("Bone Collector", "Defeat %d skeletons"),
        KILL_CREEPER("Bomb Disposal", "Defeat %d creepers"),
        KILL_SPIDER("Web Sweeper", "Defeat %d spiders"),
        USE_ABILITIES("Quirk Training", "Use quirk abilities %d times"),
        DEAL_DAMAGE("Heavy Hitter", "Deal %d damage with your power"),
        VILLAINS("Villain Attack!", "Defeat %d villains who ambush you");

        public final String title;
        public final String format;
        Type(String title, String format) { this.title = title; this.format = format; }
    }

    public Type type = Type.KILL_ANY;
    public int target = 10, progress, tier, points, xp;

    public boolean complete() { return progress >= target; }
    public String description() { return String.format(type.format, target); }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("type", type.name());
        t.putInt("target", target);
        t.putInt("progress", progress);
        t.putInt("tier", tier);
        t.putInt("points", points);
        t.putInt("xp", xp);
        return t;
    }

    public static Mission load(CompoundTag t) {
        Mission m = new Mission();
        try { m.type = Type.valueOf(t.getString("type")); } catch (IllegalArgumentException ignored) { }
        m.target = Math.max(1, t.getInt("target"));
        m.progress = t.getInt("progress");
        m.tier = t.getInt("tier");
        m.points = t.getInt("points");
        m.xp = t.getInt("xp");
        return m;
    }
}
