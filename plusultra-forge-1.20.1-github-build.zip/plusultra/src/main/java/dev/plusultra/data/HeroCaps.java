package dev.plusultra.data;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;

public final class HeroCaps {
    public static final Capability<HeroData> HERO = CapabilityManager.get(new CapabilityToken<>() {});

    private HeroCaps() {}

    public static class Provider implements ICapabilitySerializable<CompoundTag> {
        private final HeroData data = new HeroData();
        private final LazyOptional<HeroData> opt = LazyOptional.of(() -> data);

        @Override
        public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
            return cap == HERO ? opt.cast() : LazyOptional.empty();
        }

        @Override public CompoundTag serializeNBT() { return data.save(); }
        @Override public void deserializeNBT(CompoundTag tag) { data.load(tag); }
        public void invalidate() { opt.invalidate(); }
    }
}
