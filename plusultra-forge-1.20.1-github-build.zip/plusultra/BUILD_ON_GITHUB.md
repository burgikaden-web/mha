# Build the mod on GitHub

1. Create a repository on GitHub.
2. Upload the contents of this ZIP (the `plusultra` folder contents) to its root.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and select **Build Plus Ultra Forge Mod**.
5. When it completes successfully, open the run and download the `plusultra-forge-1.20.1` artifact.

The build requires Java 17 and targets Minecraft Java 1.20.1 with Forge 47.3.0.
The workflow runs `gradle build` and publishes the resulting JAR as a downloadable workflow artifact.
