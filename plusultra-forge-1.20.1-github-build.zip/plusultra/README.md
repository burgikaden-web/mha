# Plus Ultra: Hero Academia (Forge 1.20.1)

A superhero-quirk mod for **Minecraft Java 1.20.1 / Forge 47.3.0+**.
14 quirks, 56 abilities, mastery levels, skill upgrades, hero missions, hero ranks,
a Plus Ultra overdrive, a custom HUD and a full Hero Menu.

> **Status:** written without access to Forge/Minecraft jars, so it has been syntax-checked
> but **not compiled or play-tested**. Expect to fix a small number of compile errors or
> balance issues on first build (see "If the build fails").

## Building

Requires **JDK 17**.

Easiest: download the official Forge **1.20.1-47.3.0 MDK** from files.minecraftforge.net, then copy
this project's `src/` folder and `build.gradle` over the MDK's, and run:

```
./gradlew build          # jar ends up in build/libs/
./gradlew runClient      # test in a dev client
```

(This repo does not ship `gradlew`/the Gradle wrapper jar; the MDK does.)

## How to play

1. **Awakening** - new players get a random non-legendary quirk on first join (config: `autoAwakenOnFirstJoin`).
   Craft a **Quirk Awakening Scroll** (paper + diamond + XP bottle + ender pearl) and right-click it to re-roll.
   Mastery for each quirk is kept when you switch. **Legendary** quirks (One For All) can only come from scrolls.
2. **Cast abilities** with `Z` `X` `C` `V`. Each quirk has 4 abilities unlocked at mastery levels 1 / 4 / 8 / 13.
3. **Stamina** powers abilities and regenerates over time. Drink a **Stamina Drink** for +60.
4. **Mastery**: using abilities and defeating mobs levels up your equipped quirk (max Lv 20).
   Every level gives **1 skill point** and more power, stamina and cooldown reduction.
5. **Plus Ultra** (`B`, mastery Lv 5+): 20 s of x1.6 power (x2 when below 35% health), half stamina cost,
   triple regen. Afterwards you are exhausted. 5-minute cooldown.
6. **Hero Menu** (`H` or the Hero License item): Profile, Abilities, Missions, Upgrades, Codex.
7. **Missions**: accept up to 3. Kill missions, ability training, damage goals, and **Villain Attack**
   (a squad of named villains ambushes you). Rewards: hero points, mastery XP, emeralds, stamina drinks,
   and a chance at a scroll on high tiers.
8. **Hero Rank**: Trainee -> Sidekick -> Rookie Hero -> Pro Hero -> Top 10 Hero -> Symbol of Peace.
9. **Upgrades** (spend skill points, max 10 each): Power (+6% dmg), Endurance (+10 stamina),
   Recovery (+8% regen), Resilience (-2% damage taken).

## Quirks

| Quirk | Rarity | Abilities (Lv 1 / 4 / 8 / 13) |
|---|---|---|
| One For All | Legendary | Detroit Smash / Full Cowl / Delaware Smash / United States of Smash |
| Hardening | Common | Hardened Fist / Harden / Red Riot Unbreakable / Fang Rush |
| Explosion | Rare | Explosion / Stun Grenade / Howitzer Impact / AP Shot: Auto-Cannon |
| Engine | Common | Recipro Burst / Engine Dash / Recipro Extend / Recipro Overdrive |
| Half-Cold Half-Hot | Rare | Flame Burst / Ice Wall / Glacier Path / Flashfreeze Heatwave |
| Hellflame | Epic | Hellflame Fist / Flashfire Fist / Prominence Burn / Hellflame Inferno |
| Electrification | Uncommon | Zap / Chain Lightning / Static Field / Indiscriminate Discharge |
| Decay | Epic | Decay Touch / Five-Finger Decay / Decay Wave / Total Decay |
| Zero Gravity | Rare | Zero Gravity Touch / Float / Meteor Shower / Comet Home |
| Warp Gate | Epic | Warp Step / Gate Swap / Banish Gate / Warp Barrage |
| Fierce Wings | Epic | Feather Volley / Wing Dash / Storm of Feathers / Wings Unleashed (flight) |
| Frog | Common | Tongue Lash / Frog Leap / Acid Spit / Frog Frenzy |
| Dark Shadow | Uncommon | Dark Shadow Strike / Shadow Veil / Black Ankh / Eclipse (stronger in the dark) |
| Creation | Uncommon | Create Cannonball / Create Shield / Create Supplies / Cannon Barrage |

Most quirks also have a passive that grows with mastery (e.g. Hardening gives permanent
Resistance I at Lv 6, Frog gets Dolphin's Grace in water, Hellflame is fire-immune).

## Items
Quirk Awakening Scroll, Quirk Eraser Bullet, Stamina Drink, Hero License (all craftable; see `data/plusultra/recipes`).

## Commands
`/plusultra info` (everyone), and for operators (permission 2):
`/plusultra quirk set|random|clear <players> [quirk]`,
`/plusultra mastery level <players> <1-20>`, `/plusultra mastery addxp <players> <n>`,
`/plusultra points add <players> <n>`, `/plusultra stamina refill <players>`,
`/plusultra missions reroll <players>`.

## Config (`plusultra-common.toml`)
`autoAwakenOnFirstJoin`, `pvpAbilities`, `blockDamage` (explosions/decay break blocks; default off),
`damageMultiplier`, `masteryXpMultiplier`, `staminaRegenMultiplier`, `missionRewardMultiplier`.

## Project layout
```
dev/plusultra/
  PlusUltra.java            mod entry
  config/                   Forge config
  data/                     HeroData capability, Mission, serialization
  quirk/                    Quirk / Ability / registry + impl/ (the 14 quirks)
  logic/                    AbilityManager, Progression, Missions, HeroEvents
  util/                     Fx (targeting, damage, particles), Scheduler, TempBlocks
  network/                  SimpleChannel packets
  client/                   HUD, Hero Menu screen, keybinds
  command/                  /plusultra
  registry/                 items + creative tab
```

### Adding a quirk
Create a `new Quirk(id, name, type, description, rarity, color, passive, 4x Ability)` in one of the
`quirk/impl/*` classes and add a `reg(...)` line in `Quirks.java`. Abilities are lambdas that return
`true` when they fired (cost + cooldown are charged only then). The HUD, menu, codex, rolls and
mastery pick it up automatically.

## If the build fails
This was written against the 1.20.1 Forge/Mojang-mapped API from memory. If the compiler complains,
the most likely culprits are small API differences in: `GuiGraphics` helper names, `SoundEvents` constants,
`ServerPlayer`/`Entity` teleport helpers (`Fx.tp`), and `finalizeSpawn` (`Missions.spawnVillains`).
Each is isolated in one place.

## Known limitations
- Temporary blocks (ice wall, iron shield, glacier bridge) revert on a timer and when the server stops;
  they are not persisted if the server crashes mid-effect.
- Item textures are simple procedurally generated placeholders; ability icons reuse vanilla items.
- Strings are English literals (item names, keys use the lang file).
- Not designed to be balanced for competitive PvP; use `pvpAbilities=false` on survival servers if needed.
