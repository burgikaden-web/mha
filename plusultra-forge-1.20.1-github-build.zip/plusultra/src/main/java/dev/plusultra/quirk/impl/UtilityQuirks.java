package dev.plusultra.quirk.impl;

import static dev.plusultra.util.Fx.*;

import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.AbilityContext;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.QuirkRarity;
import dev.plusultra.util.Scheduler;
import dev.plusultra.util.TempBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Dark Shadow, Creation. */
public final class UtilityQuirks {
    private UtilityQuirks() {}

    /** Dark Shadow is stronger in the dark and weaker in bright light. */
    private static float dark(AbilityContext c) {
        return c.level().getMaxLocalRawBrightness(c.player().blockPosition()) <= 7 ? 1.35f : 0.85f;
    }

    public static Quirk darkShadow() {
        return new Quirk("dark_shadow", "Dark Shadow", "Symbiotic",
            "A sentient shadow lives inside you. Fierce in the dark, sluggish in the light.",
            QuirkRarity.UNCOMMON, 0x7D5FFF,
            (p, lvl) -> {
                if (p.level().getMaxLocalRawBrightness(p.blockPosition()) <= 7) buff(p, MobEffects.NIGHT_VISION, 240, 0);
            },
            new Ability("Dark Shadow Strike", Items.COAL, 1, 12, 30,
                "Your shadow lashes out at a target within 7 blocks and blinds it.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity t = target(p, 7);
                    if (t == null) return false;
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), dust(0x2B1B5C, 1.4f), from, center(t), 0.3);
                    hit(p, t, c.dmg(7) * dark(c));
                    debuff(t, MobEffects.BLINDNESS, 40, 0);
                    sound(c.level(), center(t), SoundEvents.PHANTOM_BITE, 1.2f, 0.7f);
                    return true;
                }),
            new Ability("Shadow Veil", Items.INK_SAC, 4, 25, 400,
                "Melt into the shadows: invisibility, night vision and speed.", c -> {
                    ServerPlayer p = c.player();
                    buff(p, MobEffects.INVISIBILITY, 200, 0);
                    buff(p, MobEffects.NIGHT_VISION, 400, 0);
                    buff(p, MobEffects.MOVEMENT_SPEED, 200, 1);
                    c.level().sendParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 30, 0.5, 0.8, 0.5, 0.02);
                    sound(c.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.5f);
                    return true;
                }),
            new Ability("Black Ankh", Items.ECHO_SHARD, 8, 35, 350,
                "Dark Shadow rampages in a full circle around you.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 ctr = p.position().add(0, 1, 0);
                    float dmg = c.dmg(10) * dark(c);
                    ring(c.level(), ParticleTypes.SWEEP_ATTACK, ctr, 3.0, 12);
                    ring(c.level(), dust(0x2B1B5C, 1.5f), ctr, 4.5, 24);
                    for (LivingEntity e : near(p, ctr, 6)) {
                        hit(p, e, dmg);
                        knock(e, p.position(), 1.4, 0.3);
                        debuff(e, MobEffects.BLINDNESS, 60, 0);
                    }
                    sound(c.level(), p.position(), SoundEvents.PHANTOM_BITE, 1.5f, 0.5f);
                    return true;
                }),
            new Ability("Eclipse", Items.NETHERITE_INGOT, 13, 55, 1000,
                "Plunge the area into darkness. Foes wither; you become a ravenous shadow.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 ctr = p.position().add(0, 1, 0);
                    float dmg = c.dmg(8) * dark(c);
                    for (LivingEntity e : near(p, ctr, 14)) {
                        hit(p, e, dmg);
                        debuff(e, MobEffects.DARKNESS, 160, 0);
                        debuff(e, MobEffects.WITHER, 100, 0);
                    }
                    buff(p, MobEffects.DAMAGE_BOOST, 200, 2);
                    buff(p, MobEffects.MOVEMENT_SPEED, 200, 1);
                    buff(p, MobEffects.NIGHT_VISION, 300, 0);
                    c.level().sendParticles(ParticleTypes.SCULK_SOUL, ctr.x, ctr.y, ctr.z, 80, 5, 1.5, 5, 0.05);
                    sound(c.level(), ctr, SoundEvents.WARDEN_SONIC_BOOM, 1f, 0.5f);
                    return true;
                }));
    }

    private static void shoot(AbilityContext c, double dmg, float inaccuracy) {
        ServerPlayer p = c.player();
        Arrow a = new Arrow(c.level(), p);
        a.shootFromRotation(p, p.getXRot(), p.getYRot(), 0f, 3.2f, inaccuracy);
        a.setBaseDamage(dmg);
        a.setCritArrow(true);
        a.pickup = AbstractArrow.Pickup.DISALLOWED;
        c.level().addFreshEntity(a);
    }

    public static Quirk creation() {
        return new Quirk("creation", "Creation", "Emitter",
            "Convert your body's lipids into any non-living object. Weapons, shields, supplies.",
            QuirkRarity.UNCOMMON, 0xE1AD01,
            null,
            new Ability("Create Cannonball", Items.IRON_INGOT, 1, 14, 30,
                "Create and fire a heavy iron projectile.", c -> {
                    shoot(c, 2.4 * c.power(), 0.5f);
                    sound(c.level(), c.player().position(), SoundEvents.ARROW_SHOOT, 1f, 0.6f);
                    return true;
                }),
            new Ability("Create Shield", Items.SHIELD, 4, 25, 350,
                "Create a wall of solid iron in front of you for 10 seconds.", c -> {
                    ServerPlayer p = c.player();
                    Direction f = p.getDirection();
                    Direction r = f.getClockWise();
                    BlockPos base = p.blockPosition().relative(f, 2);
                    int placed = 0;
                    for (int w = -2; w <= 2; w++) {
                        for (int h = 0; h < 3; h++) {
                            if (TempBlocks.place(c.level(), base.relative(r, w).above(h), Blocks.IRON_BLOCK.defaultBlockState(), 200)) placed++;
                        }
                    }
                    if (placed == 0) return false;
                    sound(c.level(), p.position(), SoundEvents.ANVIL_PLACE, 1f, 1f);
                    return true;
                }),
            new Ability("Create Supplies", Items.COOKED_BEEF, 8, 30, 600,
                "Create food and medical supplies: hunger, regeneration and absorption.", c -> {
                    ServerPlayer p = c.player();
                    p.getFoodData().eat(10, 0.8f);
                    buff(p, MobEffects.REGENERATION, 100, 1);
                    buff(p, MobEffects.ABSORPTION, 200, 1);
                    c.level().sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 20, 0.5, 0.8, 0.5, 0.1);
                    sound(c.level(), p.position(), SoundEvents.PLAYER_BURP, 1f, 1.2f);
                    return true;
                }),
            new Ability("Cannon Barrage", Items.CROSSBOW, 13, 55, 900,
                "Create a battery of cannons: ten rapid shots in a tight spread.", c -> {
                    ServerPlayer p = c.player();
                    double dmg = 2.0 * c.power();
                    Scheduler.repeat(3, 10, i -> {
                        if (!p.isAlive()) return;
                        shoot(c, dmg, 6f);
                        sound(c.level(), p.position(), SoundEvents.ARROW_SHOOT, 0.8f, 0.8f);
                    });
                    return true;
                }));
    }
}
