package dev.plusultra.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    public static final String CATEGORY = "key.categories.plusultra";
    public static final KeyMapping[] ABILITY = {
        new KeyMapping("key.plusultra.ability1", GLFW.GLFW_KEY_Z, CATEGORY),
        new KeyMapping("key.plusultra.ability2", GLFW.GLFW_KEY_X, CATEGORY),
        new KeyMapping("key.plusultra.ability3", GLFW.GLFW_KEY_C, CATEGORY),
        new KeyMapping("key.plusultra.ability4", GLFW.GLFW_KEY_V, CATEGORY)
    };
    public static final KeyMapping PLUS_ULTRA = new KeyMapping("key.plusultra.plus_ultra", GLFW.GLFW_KEY_B, CATEGORY);
    public static final KeyMapping MENU = new KeyMapping("key.plusultra.menu", GLFW.GLFW_KEY_H, CATEGORY);

    private Keys() {}
}
