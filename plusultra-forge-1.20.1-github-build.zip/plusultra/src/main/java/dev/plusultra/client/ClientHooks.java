package dev.plusultra.client;

import dev.plusultra.data.HeroData;
import dev.plusultra.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

/** Entry points called from network packets / items (only ever loaded on the client). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void onSync(CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || tag == null) return;
        HeroData.get(mc.player).load(tag);
        if (mc.screen instanceof HeroScreen s) s.refresh();
    }

    public static void onLight(ModNetwork.LightPacket m) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        HeroData d = HeroData.get(mc.player);
        d.stamina = m.stamina;
        System.arraycopy(m.cd, 0, d.cooldowns, 0, HeroData.SLOTS);
        System.arraycopy(m.cdMax, 0, d.cooldownMax, 0, HeroData.SLOTS);
        d.plusUltraTicks = m.puTicks;
        d.plusUltraCooldown = m.puCooldown;
    }

    public static void openMenu() {
        Minecraft.getInstance().setScreen(new HeroScreen());
    }
}
