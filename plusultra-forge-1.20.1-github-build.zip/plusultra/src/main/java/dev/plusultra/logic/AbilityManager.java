package dev.plusultra.logic;

import dev.plusultra.PlusUltra;
import dev.plusultra.data.HeroData;
import dev.plusultra.data.Mission;
import dev.plusultra.network.ModNetwork;
import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.AbilityContext;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.util.Fx;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffects;

/** Server-side casting rules: unlocks, cooldowns, stamina, XP, Plus Ultra. */
public final class AbilityManager {
    public static final int PLUS_ULTRA_LEVEL = 5;
    public static final int PLUS_ULTRA_DURATION = 400;
    public static final int PLUS_ULTRA_COOLDOWN = 6000;

    private AbilityManager() {}

    public static void cast(ServerPlayer p, int slot) {
        if (p.isSpectator() || !p.isAlive()) return;
        HeroData d = HeroData.get(p);
        Quirk q = d.quirk();
        if (q == null) {
            Fx.msg(p, "You don't have a quirk yet! Craft or find an Awakening Scroll.");
            return;
        }
        if (slot < 0 || slot >= q.abilities.size()) return;
        Ability a = q.abilities.get(slot);
        int lvl = d.level();
        if (lvl < a.unlock) {
            Fx.msg(p, a.name + " unlocks at mastery level " + a.unlock);
            return;
        }
        if (d.cooldowns[slot] > 0) return;
        float cost = a.cost * (d.plusUltraActive() ? 0.5f : 1f);
        if (d.stamina < cost) {
            Fx.msg(p, "Not enough stamina!");
            p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.6f, 0.6f);
            return;
        }

        AbilityContext ctx = new AbilityContext(p, p.serverLevel(), d, d.power(p));
        boolean ok;
        try {
            ok = a.effect.cast(ctx);
        } catch (Exception ex) {
            PlusUltra.LOG.error("Ability {} failed", a.name, ex);
            ok = false;
        }
        if (!ok) {
            Fx.msg(p, a.name + ": no valid target");
            return;
        }

        d.stamina -= cost;
        int cd = Math.max(10, (int) (a.cooldown * (1f - 0.015f * (lvl - 1))));
        d.cooldowns[slot] = cd;
        d.cooldownMax[slot] = cd;
        d.lastCastTick = p.level().getGameTime();
        d.totalCasts++;
        Progression.giveXpScaled(p, d, 5 + a.cost / 4.0);
        Missions.progress(p, d, Mission.Type.USE_ABILITIES, 1);
        ModNetwork.sendLight(p, d);
        d.lastSentStamina = d.stamina;
    }

    public static void plusUltra(ServerPlayer p) {
        if (p.isSpectator() || !p.isAlive()) return;
        HeroData d = HeroData.get(p);
        Quirk q = d.quirk();
        if (q == null) return;
        if (d.level() < PLUS_ULTRA_LEVEL) {
            Fx.msg(p, "Plus Ultra unlocks at mastery level " + PLUS_ULTRA_LEVEL);
            return;
        }
        if (d.plusUltraActive()) return;
        if (d.plusUltraCooldown > 0) {
            Fx.msg(p, "Plus Ultra is recharging: " + (d.plusUltraCooldown / 20) + "s");
            return;
        }
        d.plusUltraTicks = PLUS_ULTRA_DURATION;
        d.plusUltraCooldown = PLUS_ULTRA_DURATION + PLUS_ULTRA_COOLDOWN;
        d.stamina = d.maxStamina();
        Fx.buff(p, MobEffects.DAMAGE_BOOST, PLUS_ULTRA_DURATION, 0);
        p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 30, 10));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("Power x1.6 | half stamina cost | triple regen")
                .withStyle(ChatFormatting.YELLOW)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("PLUS ULTRA!")
                .withStyle(Style.EMPTY.withColor(q.color).withBold(true))));
        p.serverLevel().sendParticles(ParticleTypes.FLASH, p.getX(), p.getY() + 1, p.getZ(), 2, 0, 0, 0, 0);
        p.serverLevel().sendParticles(Fx.dust(q.color, 1.6f), p.getX(), p.getY() + 1, p.getZ(), 60, 0.6, 1.0, 0.6, 0.1);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.5f, 1.5f);
        d.dirty = true;
    }

    public static void endPlusUltra(ServerPlayer p, HeroData d) {
        Fx.debuff(p, MobEffects.WEAKNESS, 200, 1);
        Fx.debuff(p, MobEffects.MOVEMENT_SLOWDOWN, 200, 0);
        d.stamina = Math.min(d.stamina, 10f);
        Fx.msg(p, "Plus Ultra faded... you are exhausted!");
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1f, 1f);
        d.dirty = true;
    }

    public static void upgrade(ServerPlayer p, int stat) {
        HeroData d = HeroData.get(p);
        if (stat < 0 || stat >= d.stats.length) return;
        if (d.skillPoints <= 0 || d.stats[stat] >= HeroData.MAX_STAT) return;
        d.skillPoints--;
        d.stats[stat]++;
        d.dirty = true;
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 0.5f, 1.6f);
    }
}
