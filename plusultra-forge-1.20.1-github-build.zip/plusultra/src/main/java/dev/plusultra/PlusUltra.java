package dev.plusultra;

import com.mojang.logging.LogUtils;
import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.data.HeroData;
import dev.plusultra.network.ModNetwork;
import dev.plusultra.registry.ModItems;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(PlusUltra.MODID)
public class PlusUltra {
    public static final String MODID = "plusultra";
    public static final Logger LOG = LogUtils.getLogger();

    public PlusUltra() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PlusUltraConfig.SPEC);
        bus.addListener((RegisterCapabilitiesEvent ev) -> ev.register(HeroData.class));
        bus.addListener((FMLCommonSetupEvent ev) -> ev.enqueueWork(ModNetwork::init));
    }
}
