package dev.plusultra.quirk;

import dev.plusultra.quirk.impl.ElementQuirks;
import dev.plusultra.quirk.impl.MobilityQuirks;
import dev.plusultra.quirk.impl.PowerQuirks;
import dev.plusultra.quirk.impl.UtilityQuirks;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.util.RandomSource;

public final class Quirks {
    private static final Map<String, Quirk> REG = new LinkedHashMap<>();

    static {
        reg(PowerQuirks.oneForAll());
        reg(PowerQuirks.hardening());
        reg(PowerQuirks.explosion());
        reg(PowerQuirks.engine());
        reg(ElementQuirks.halfColdHalfHot());
        reg(ElementQuirks.hellflame());
        reg(ElementQuirks.electrification());
        reg(ElementQuirks.decay());
        reg(MobilityQuirks.zeroGravity());
        reg(MobilityQuirks.warpGate());
        reg(MobilityQuirks.fierceWings());
        reg(MobilityQuirks.frog());
        reg(UtilityQuirks.darkShadow());
        reg(UtilityQuirks.creation());
    }

    private Quirks() {}

    private static void reg(Quirk q) { REG.put(q.id, q); }

    public static Quirk get(String id) { return id == null ? null : REG.get(id); }
    public static Collection<Quirk> all() { return REG.values(); }
    public static Set<String> ids() { return REG.keySet(); }

    /** Weighted random quirk, never {@code exclude}. */
    public static Quirk roll(RandomSource r, String exclude, boolean allowLegendary) {
        int total = 0;
        for (Quirk q : REG.values()) if (eligible(q, exclude, allowLegendary)) total += q.rarity.weight;
        int roll = r.nextInt(Math.max(1, total));
        Quirk last = null;
        for (Quirk q : REG.values()) {
            if (!eligible(q, exclude, allowLegendary)) continue;
            last = q;
            roll -= q.rarity.weight;
            if (roll < 0) return q;
        }
        return last != null ? last : REG.values().iterator().next();
    }

    private static boolean eligible(Quirk q, String exclude, boolean allowLegendary) {
        return !q.id.equals(exclude) && (allowLegendary || q.rarity != QuirkRarity.LEGENDARY);
    }
}
