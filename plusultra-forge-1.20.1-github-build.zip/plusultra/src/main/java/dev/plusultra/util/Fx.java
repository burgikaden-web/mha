package dev.plusultra.util;

import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.quirk.AbilityContext;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Shared helpers for ability implementations: targeting, damage, particles, sounds, movement. */
public final class Fx {
    private Fx() {}

    // ------------------------------------------------------------------ targeting

    public static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e.isSpectator() || e instanceof ArmorStand) return false;
        if (e.isAlliedTo(p)) return false;
        if (e instanceof TamableAnimal t && t.isOwnedBy(p)) return false;
        if (e instanceof Player && !PlusUltraConfig.PVP_ABILITIES.get()) return false;
        return true;
    }

    public static Vec3 center(Entity e) { return e.getBoundingBox().getCenter(); }

    public static List<LivingEntity> near(ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r).inflate(1);
        double lim = (r + 0.6) * (r + 0.6);
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, box,
                e -> valid(p, e) && e.getBoundingBox().getCenter().distanceToSqr(c) <= lim);
    }

    public static List<LivingEntity> cone(ServerPlayer p, double range, double halfAngleDeg) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double cos = Math.cos(Math.toRadians(halfAngleDeg));
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : near(p, eye, range)) {
            Vec3 to = center(e).subtract(eye);
            if (to.lengthSqr() < 1.0 || to.normalize().dot(look) >= cos) out.add(e);
        }
        return out;
    }

    public static LivingEntity target(ServerPlayer p, double range) {
        return target(p, p.getEyePosition(), p.getLookAngle(), range);
    }

    public static LivingEntity target(ServerPlayer p, Vec3 from, Vec3 dir, double range) {
        Vec3 end = from.add(dir.scale(range));
        HitResult br = p.level().clip(new ClipContext(from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (br.getType() != HitResult.Type.MISS) end = br.getLocation();
        double max = from.distanceTo(end);
        AABB box = new AABB(from, end).inflate(1.5);
        LivingEntity best = null;
        double bestDist = max + 0.01;
        for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
            AABB bb = e.getBoundingBox().inflate(0.3);
            double d;
            if (bb.contains(from)) {
                d = 0;
            } else {
                Optional<Vec3> hit = bb.clip(from, end);
                if (hit.isEmpty()) continue;
                d = from.distanceTo(hit.get());
            }
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    /** Point the player is looking at: target entity centre, else block hit, else max range. */
    public static Vec3 aim(ServerPlayer p, double range) {
        LivingEntity t = target(p, range);
        if (t != null) return center(t);
        Vec3 from = p.getEyePosition();
        Vec3 end = from.add(p.getLookAngle().scale(range));
        HitResult br = p.level().clip(new ClipContext(from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return br.getType() == HitResult.Type.MISS ? end : br.getLocation();
    }

    public static boolean solid(ServerLevel l, Vec3 v) {
        BlockPos bp = BlockPos.containing(v);
        return !l.getBlockState(bp).getCollisionShape(l, bp).isEmpty();
    }

    // ------------------------------------------------------------------ damage & movement

    public static void hit(ServerPlayer p, LivingEntity t, float dmg) {
        t.invulnerableTime = 0;
        t.hurt(p.damageSources().playerAttack(p), dmg);
    }

    public static void selfHurt(ServerPlayer p, float dmg) {
        if (p.getHealth() > dmg + 2f) p.hurt(p.damageSources().generic(), dmg);
    }

    public static void push(Entity e, Vec3 v) {
        e.setDeltaMovement(v);
        e.hurtMarked = true;
    }

    public static void knock(LivingEntity t, Vec3 from, double strength, double up) {
        Vec3 d = t.position().subtract(from);
        d = new Vec3(d.x, 0, d.z);
        d = d.lengthSqr() < 1.0E-4 ? Vec3.ZERO : d.normalize().scale(strength);
        double resist = Mth.clamp(t.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE), 0, 1);
        d = d.scale(1.0 - resist);
        push(t, t.getDeltaMovement().add(d.x, up, d.z));
    }

    public static void tp(Entity e, Vec3 v) {
        if (e instanceof ServerPlayer sp) sp.connection.teleport(v.x, v.y, v.z, sp.getYRot(), sp.getXRot());
        else e.moveTo(v.x, v.y, v.z, e.getYRot(), e.getXRot());
        e.fallDistance = 0;
    }

    public static Vec3 randomSpot(ServerLevel l, Vec3 c, double min, double max) {
        double a = l.random.nextDouble() * Math.PI * 2;
        double d = min + l.random.nextDouble() * (max - min);
        int x = Mth.floor(c.x + Math.cos(a) * d);
        int z = Mth.floor(c.z + Math.sin(a) * d);
        int y = l.dimensionType().hasCeiling() ? Mth.floor(c.y) : l.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        return new Vec3(x + 0.5, y, z + 0.5);
    }

    public static void setFlight(ServerPlayer p, boolean on) {
        if (p.isCreative() || p.isSpectator()) return;
        p.getAbilities().mayfly = on;
        p.getAbilities().flying = on;
        if (on) p.getPersistentData().putBoolean("plusultra_flight", true);
        else p.getPersistentData().remove("plusultra_flight");
        p.onUpdateAbilities();
    }

    /** Dash in the look direction, hitting everything you pass through once. */
    public static void dashAttack(AbilityContext c, double speed, double up, int ticks, double radius,
                                  float dmg, double knock, ParticleOptions trail) {
        ServerPlayer p = c.player();
        Vec3 look = p.getLookAngle();
        push(p, new Vec3(look.x * speed, look.y * speed * 0.6 + up, look.z * speed));
        p.fallDistance = 0;
        Set<UUID> seen = new HashSet<>();
        Scheduler.repeat(1, ticks, i -> {
            if (!p.isAlive()) return;
            p.fallDistance = 0;
            c.level().sendParticles(trail, p.getX(), p.getY() + 1, p.getZ(), 6, 0.3, 0.4, 0.3, 0.02);
            if (dmg > 0 && radius > 0) {
                for (LivingEntity e : near(p, p.position().add(0, 1, 0), radius)) {
                    if (seen.add(e.getUUID())) {
                        hit(p, e, dmg);
                        knock(e, p.position(), knock, 0.3);
                    }
                }
            }
        });
    }

    // ------------------------------------------------------------------ effects

    /** Self buff without swirling particles. */
    public static void buff(LivingEntity e, MobEffect m, int ticks, int amp) {
        e.addEffect(new MobEffectInstance(m, ticks, amp, false, false, true));
    }

    /** Debuff with visible particles. */
    public static void debuff(LivingEntity e, MobEffect m, int ticks, int amp) {
        e.addEffect(new MobEffectInstance(m, ticks, amp, false, true, true));
    }

    public static void msg(ServerPlayer p, String s) {
        p.displayClientMessage(Component.literal(s), true);
    }

    // ------------------------------------------------------------------ particles & sound

    public static DustParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f), size);
    }

    public static void sound(Level l, Vec3 pos, SoundEvent s, float vol, float pitch) {
        l.playSound(null, pos.x, pos.y, pos.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void line(ServerLevel l, ParticleOptions o, Vec3 a, Vec3 b, double step) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 n = d.scale(1.0 / len);
        for (double t = 0; t <= len; t += step) {
            Vec3 v = a.add(n.scale(t));
            l.sendParticles(o, v.x, v.y, v.z, 1, 0.03, 0.03, 0.03, 0);
        }
    }

    public static void ring(ServerLevel l, ParticleOptions o, Vec3 c, double r, int points) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            l.sendParticles(o, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r, 1, 0, 0.05, 0, 0.01);
        }
    }

    public static void impact(ServerLevel l, Vec3 v) {
        l.sendParticles(ParticleTypes.EXPLOSION, v.x, v.y, v.z, 1, 0, 0, 0, 0);
        l.sendParticles(ParticleTypes.CRIT, v.x, v.y, v.z, 18, 0.3, 0.3, 0.3, 0.4);
        sound(l, v, SoundEvents.PLAYER_ATTACK_STRONG, 1.3f, 0.8f);
    }

    public static void bolt(ServerLevel l, Vec3 pos) {
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(l);
        if (b == null) return;
        b.moveTo(pos);
        b.setVisualOnly(true);
        l.addFreshEntity(b);
    }

    /** Area blast: damage with falloff + knockback. Only destroys blocks if enabled in config. */
    public static void blast(ServerPlayer p, Vec3 c, float radius, float dmg, double knock) {
        ServerLevel l = p.serverLevel();
        l.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 2 + (int) radius, radius * 0.4, radius * 0.3, radius * 0.4, 0);
        l.sendParticles(ParticleTypes.FLAME, c.x, c.y, c.z, 12 + (int) (radius * 4), radius * 0.4, radius * 0.3, radius * 0.4, 0.05);
        l.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y, c.z, 6, radius * 0.4, radius * 0.3, radius * 0.4, 0.02);
        sound(l, c, SoundEvents.GENERIC_EXPLODE, 1.2f, 1.0f);
        for (LivingEntity e : near(p, c, radius)) {
            double dist = center(e).distanceTo(c);
            double f = Mth.clamp(1.0 - dist / (radius + 1.0), 0.0, 1.0);
            hit(p, e, (float) (dmg * (0.45 + 0.55 * f)));
            knock(e, c, knock * (0.4 + 0.6 * f), 0.35 * f + 0.1);
        }
        if (PlusUltraConfig.BLOCK_DAMAGE.get()) {
            l.explode(null, c.x, c.y, c.z, radius * 0.6f, Level.ExplosionInteraction.MOB);
        }
    }

    /** Decay: crumbles foliage / grass / stone nearby. Only when block damage is enabled. */
    public static void decayBlocks(ServerLevel l, BlockPos c, int r) {
        if (!PlusUltraConfig.BLOCK_DAMAGE.get()) return;
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
            if (pos.distSqr(c) > r * r) continue;
            BlockState s = l.getBlockState(pos);
            BlockPos ip = pos.immutable();
            if (s.is(BlockTags.LEAVES) || s.is(BlockTags.FLOWERS) || s.is(BlockTags.CROPS)) l.destroyBlock(ip, false);
            else if (s.is(Blocks.GRASS_BLOCK)) l.setBlockAndUpdate(ip, Blocks.COARSE_DIRT.defaultBlockState());
            else if (s.is(Blocks.STONE)) l.setBlockAndUpdate(ip, Blocks.COBBLESTONE.defaultBlockState());
        }
    }
}
