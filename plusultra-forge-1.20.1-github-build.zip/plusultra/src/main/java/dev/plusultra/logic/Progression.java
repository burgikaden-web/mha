package dev.plusultra.logic;

import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.data.HeroData;
import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.QuirkRarity;
import java.util.Arrays;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/** Mastery levels, hero ranks and quirk awakening. */
public final class Progression {
    public static final String[] RANKS = {"Trainee", "Sidekick", "Rookie Hero", "Pro Hero", "Top 10 Hero", "Symbol of Peace"};
    public static final int[] RANK_POINTS = {0, 100, 400, 1000, 2500, 6000};
    private static final String[] MASTERY = {"Novice", "Apprentice", "Adept", "Expert", "Master", "Grandmaster"};

    private Progression() {}

    /** Total mastery XP required to reach a level. */
    public static int xpToReach(int level) {
        int l = Math.max(1, Math.min(level, HeroData.MAX_LEVEL));
        return 25 * (l - 1) * (l - 1);
    }

    public static int levelForXp(int xp) {
        int l = 1;
        while (l < HeroData.MAX_LEVEL && xp >= xpToReach(l + 1)) l++;
        return l;
    }

    public static String masteryTitle(int level) {
        if (level >= HeroData.MAX_LEVEL) return MASTERY[5];
        return MASTERY[Math.min(4, (level - 1) / 4)];
    }

    public static int rank(int points) {
        int r = 0;
        for (int i = 0; i < RANK_POINTS.length; i++) if (points >= RANK_POINTS[i]) r = i;
        return r;
    }

    /** Adds mastery XP to the equipped quirk, handling level-ups, skill points and unlock messages. */
    public static void giveXp(ServerPlayer p, HeroData d, int amount) {
        Quirk q = d.quirk();
        if (q == null || amount <= 0) return;
        int before = d.level();
        int cap = xpToReach(HeroData.MAX_LEVEL);
        d.xp.put(q.id, Math.min(cap, d.quirkXp() + amount));
        int after = d.level();
        d.dirty = true;
        if (after <= before) return;

        for (int lvl = before + 1; lvl <= after; lvl++) {
            d.skillPoints++;
            p.sendSystemMessage(Component.literal("* " + q.name + " mastery reached level " + lvl + " (" + masteryTitle(lvl) + ")! +1 skill point")
                    .withStyle(Style.EMPTY.withColor(q.color)));
            for (Ability a : q.abilities) {
                if (a.unlock == lvl) {
                    p.sendSystemMessage(Component.literal("  New ability unlocked: " + a.name).withStyle(ChatFormatting.GOLD));
                }
            }
        }
        p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 15));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(q.name + " - " + masteryTitle(after))
                .withStyle(Style.EMPTY.withColor(q.color))));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("LEVEL " + after).withStyle(ChatFormatting.BOLD)));
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1.2f);
    }

    public static void giveXpScaled(ServerPlayer p, HeroData d, double base) {
        giveXp(p, d, (int) Math.max(1, Math.round(base * PlusUltraConfig.XP_MULT.get())));
    }

    public static void addPoints(ServerPlayer p, HeroData d, int pts) {
        int before = rank(d.heroPoints);
        d.heroPoints += pts;
        int after = rank(d.heroPoints);
        d.dirty = true;
        if (after > before) {
            p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
            p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("You are now a " + RANKS[after]).withStyle(ChatFormatting.YELLOW)));
            p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("RANK UP!").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)));
            p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
            if (after >= 3) {
                p.server.getPlayerList().broadcastSystemMessage(
                        Component.literal(p.getName().getString() + " has risen to the rank of " + RANKS[after] + "!").withStyle(ChatFormatting.GOLD), false);
            }
        }
    }

    /** Gives the player a quirk with a title screen and effects. */
    public static void awaken(ServerPlayer p, HeroData d, Quirk q) {
        d.quirkId = q.id;
        d.xp.putIfAbsent(q.id, 0);
        d.stamina = d.maxStamina();
        Arrays.fill(d.cooldowns, 0);
        d.dirty = true;
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(q.rarity.label + " - " + q.type)
                .withStyle(Style.EMPTY.withColor(q.rarity.color))));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(q.name)
                .withStyle(Style.EMPTY.withColor(q.color).withBold(true))));
        p.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 60, 0.6, 1.0, 0.6, 0.4);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
        p.sendSystemMessage(Component.literal("Your quirk awakened: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(q.name).withStyle(Style.EMPTY.withColor(q.color).withBold(true)))
                .append(Component.literal("  (press H for the Hero Menu)").withStyle(ChatFormatting.DARK_GRAY)));
        if (q.rarity.ordinal() >= QuirkRarity.EPIC.ordinal()) {
            p.server.getPlayerList().broadcastSystemMessage(
                    Component.literal(p.getName().getString() + " awakened a " + q.rarity.label + " quirk: " + q.name + "!")
                            .withStyle(Style.EMPTY.withColor(q.rarity.color)), false);
        }
    }
}
