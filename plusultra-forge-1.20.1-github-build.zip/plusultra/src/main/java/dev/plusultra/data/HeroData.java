package dev.plusultra.data;

import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.logic.Progression;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.Quirks;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/** All per-player hero state. Attached to every player as a capability. */
public class HeroData {
    public static final int SLOTS = 4;
    public static final int MAX_LEVEL = 20;
    public static final int MAX_ACTIVE = 3;
    public static final int MAX_OFFERS = 3;
    public static final int MAX_STAT = 10;
    public static final String[] STAT_NAMES = {"Power", "Endurance", "Recovery", "Resilience"};

    public String quirkId = "";
    public boolean awakened;
    public final Map<String, Integer> xp = new HashMap<>();
    public float stamina = 100f;
    public final int[] cooldowns = new int[SLOTS];
    public final int[] cooldownMax = new int[SLOTS];
    public int plusUltraTicks, plusUltraCooldown;
    public int heroPoints, skillPoints, missionsCompleted, totalCasts, totalKills;
    public final int[] stats = new int[4];
    public final List<Mission> active = new ArrayList<>();
    public final List<Mission> offers = new ArrayList<>();

    // transient (never saved)
    public long lastCastTick;
    public int flightTicks;
    public boolean dirty;
    public float lastSentStamina = -1f;

    public static HeroData get(Player p) {
        return p.getCapability(HeroCaps.HERO).orElseGet(HeroData::new);
    }

    public Quirk quirk() { return Quirks.get(quirkId); }
    public int quirkXp() { return xp.getOrDefault(quirkId, 0); }
    public int level() { return quirkId.isEmpty() ? 1 : Progression.levelForXp(quirkXp()); }
    public int levelOf(String id) { return Progression.levelForXp(xp.getOrDefault(id, 0)); }

    public float maxStamina() { return 100f + 5f * (level() - 1) + 10f * stats[1]; }

    public float regenPerTick() {
        float r = (4f + 0.2f * level()) * (1f + 0.08f * stats[2]);
        if (plusUltraActive()) r *= 3f;
        return r * PlusUltraConfig.REGEN_MULT.get().floatValue() / 20f;
    }

    public boolean plusUltraActive() { return plusUltraTicks > 0; }

    public float power(LivingEntity e) {
        float p = (1f + 0.05f * (level() - 1)) * (1f + 0.06f * stats[0]);
        if (plusUltraActive()) p *= e.getHealth() < e.getMaxHealth() * 0.35f ? 2.0f : 1.6f;
        return p;
    }

    /** Ticks cooldowns and Plus Ultra. Returns true on the tick Plus Ultra ends. */
    public boolean tickTimers() {
        for (int i = 0; i < SLOTS; i++) if (cooldowns[i] > 0) cooldowns[i]--;
        if (plusUltraCooldown > 0) plusUltraCooldown--;
        if (plusUltraTicks > 0) {
            plusUltraTicks--;
            return plusUltraTicks == 0;
        }
        return false;
    }

    public void resetTransient() {
        Arrays.fill(cooldowns, 0);
        plusUltraTicks = 0;
        flightTicks = 0;
        stamina = maxStamina();
        dirty = true;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("quirk", quirkId);
        t.putBoolean("awakened", awakened);
        CompoundTag x = new CompoundTag();
        xp.forEach(x::putInt);
        t.put("xp", x);
        t.putFloat("stamina", stamina);
        t.putIntArray("cd", cooldowns);
        t.putIntArray("cdMax", cooldownMax);
        t.putInt("puT", plusUltraTicks);
        t.putInt("puC", plusUltraCooldown);
        t.putInt("heroPoints", heroPoints);
        t.putInt("skillPoints", skillPoints);
        t.putInt("missionsDone", missionsCompleted);
        t.putInt("casts", totalCasts);
        t.putInt("kills", totalKills);
        t.putIntArray("stats", stats);
        t.put("active", saveMissions(active));
        t.put("offers", saveMissions(offers));
        return t;
    }

    public void load(CompoundTag t) {
        quirkId = t.getString("quirk");
        awakened = t.getBoolean("awakened");
        xp.clear();
        CompoundTag x = t.getCompound("xp");
        for (String k : x.getAllKeys()) xp.put(k, x.getInt(k));
        stamina = t.contains("stamina") ? t.getFloat("stamina") : 100f;
        copy(t.getIntArray("cd"), cooldowns);
        copy(t.getIntArray("cdMax"), cooldownMax);
        plusUltraTicks = t.getInt("puT");
        plusUltraCooldown = t.getInt("puC");
        heroPoints = t.getInt("heroPoints");
        skillPoints = t.getInt("skillPoints");
        missionsCompleted = t.getInt("missionsDone");
        totalCasts = t.getInt("casts");
        totalKills = t.getInt("kills");
        copy(t.getIntArray("stats"), stats);
        loadMissions(t.getList("active", Tag.TAG_COMPOUND), active);
        loadMissions(t.getList("offers", Tag.TAG_COMPOUND), offers);
    }

    private static void copy(int[] src, int[] dst) {
        Arrays.fill(dst, 0);
        System.arraycopy(src, 0, dst, 0, Math.min(src.length, dst.length));
    }

    private static ListTag saveMissions(List<Mission> l) {
        ListTag t = new ListTag();
        for (Mission m : l) t.add(m.save());
        return t;
    }

    private static void loadMissions(ListTag t, List<Mission> out) {
        out.clear();
        for (int i = 0; i < t.size(); i++) out.add(Mission.load(t.getCompound(i)));
    }
}
