package dev.plusultra.registry;

import dev.plusultra.PlusUltra;
import dev.plusultra.client.ClientHooks;
import dev.plusultra.data.HeroData;
import dev.plusultra.logic.Progression;
import dev.plusultra.network.ModNetwork;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.Quirks;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.jetbrains.annotations.Nullable;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PlusUltra.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PlusUltra.MODID);

    public static final RegistryObject<Item> AWAKENING_SCROLL = ITEMS.register("awakening_scroll",
            () -> new AwakeningScroll(new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> QUIRK_ERASER_BULLET = ITEMS.register("quirk_eraser_bullet",
            () -> new EraserBullet(new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> STAMINA_DRINK = ITEMS.register("stamina_drink",
            () -> new StaminaDrink(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> HERO_LICENSE = ITEMS.register("hero_license",
            () -> new HeroLicense(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.plusultra"))
                    .icon(() -> new ItemStack(AWAKENING_SCROLL.get()))
                    .displayItems((params, out) -> ITEMS.getEntries().forEach(i -> out.accept(i.get())))
                    .build());

    private ModItems() {}

    /** Right-click: roll a random quirk (weighted by rarity). Your mastery for each quirk is kept. */
    public static class AwakeningScroll extends Item {
        public AwakeningScroll(Properties p) { super(p); }

        @Override public boolean isFoil(ItemStack s) { return true; }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack st = player.getItemInHand(hand);
            if (player instanceof ServerPlayer sp) {
                HeroData d = HeroData.get(sp);
                Quirk q = Quirks.roll(sp.getRandom(), d.quirkId, true);
                Progression.awaken(sp, d, q);
                if (!sp.getAbilities().instabuild) st.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(st, level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
            tip.add(Component.literal("Right-click to awaken a random quirk.").withStyle(ChatFormatting.GRAY));
            tip.add(Component.literal("Mastery of each quirk is kept when you switch.").withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    /** Right-click: removes your current quirk (mastery is kept). */
    public static class EraserBullet extends Item {
        public EraserBullet(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack st = player.getItemInHand(hand);
            if (player instanceof ServerPlayer sp) {
                HeroData d = HeroData.get(sp);
                if (d.quirkId.isEmpty()) {
                    sp.displayClientMessage(Component.literal("You have no quirk to erase."), true);
                    return InteractionResultHolder.fail(st);
                }
                d.quirkId = "";
                d.dirty = true;
                sp.displayClientMessage(Component.literal("Your quirk has been erased..."), true);
                if (!sp.getAbilities().instabuild) st.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(st, level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
            tip.add(Component.literal("Right-click to erase your quirk.").withStyle(ChatFormatting.RED));
        }
    }

    public static class StaminaDrink extends Item {
        public StaminaDrink(Properties p) { super(p); }

        @Override public UseAnim getUseAnimation(ItemStack s) { return UseAnim.DRINK; }
        @Override public int getUseDuration(ItemStack s) { return 32; }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            return ItemUtils.startUsingInstantly(level, player, hand);
        }

        @Override
        public ItemStack finishUsingItem(ItemStack s, Level level, LivingEntity e) {
            if (!level.isClientSide() && e instanceof ServerPlayer sp) {
                HeroData d = HeroData.get(sp);
                d.stamina = Math.min(d.maxStamina(), d.stamina + 60f);
                ModNetwork.sendLight(sp, d);
                d.lastSentStamina = d.stamina;
                if (!sp.getAbilities().instabuild) {
                    s.shrink(1);
                    if (s.isEmpty()) return new ItemStack(Items.GLASS_BOTTLE);
                    sp.getInventory().add(new ItemStack(Items.GLASS_BOTTLE));
                }
            }
            return s;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
            tip.add(Component.literal("Restores 60 stamina.").withStyle(ChatFormatting.AQUA));
        }
    }

    /** Right-click: opens the Hero Menu. */
    public static class HeroLicense extends Item {
        public HeroLicense(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (level.isClientSide()) DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openMenu);
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> tip, TooltipFlag f) {
            tip.add(Component.literal("Right-click or press H to open the Hero Menu.").withStyle(ChatFormatting.GRAY));
        }
    }
}
