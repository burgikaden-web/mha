package dev.plusultra.quirk.impl;

import static dev.plusultra.util.Fx.*;

import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.QuirkRarity;
import dev.plusultra.util.Scheduler;
import dev.plusultra.util.TempBlocks;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Half-Cold Half-Hot, Hellflame, Electrification, Decay. */
public final class ElementQuirks {
    private ElementQuirks() {}

    public static Quirk halfColdHalfHot() {
        return new Quirk("half_cold_half_hot", "Half-Cold Half-Hot", "Emitter",
            "Ice on the right, flames on the left. Freeze the battlefield, then set it ablaze.",
            QuirkRarity.RARE, 0x6EC6FF,
            (p, lvl) -> { if (lvl >= 3) buff(p, MobEffects.FIRE_RESISTANCE, 60, 0); },
            new Ability("Flame Burst", Items.BLAZE_POWDER, 1, 12, 40,
                "Unleash a cone of flames from your left side.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), ParticleTypes.FLAME, from, from.add(c.look().scale(8)), 0.5);
                    for (LivingEntity e : cone(p, 8, 40)) {
                        hit(p, e, c.dmg(6));
                        e.setSecondsOnFire(5);
                    }
                    sound(c.level(), p.position(), SoundEvents.BLAZE_SHOOT, 1f, 0.8f);
                    return true;
                }),
            new Ability("Ice Wall", Items.PACKED_ICE, 4, 25, 300,
                "Raise a towering wall of packed ice in front of you.", c -> {
                    ServerPlayer p = c.player();
                    Direction f = p.getDirection();
                    Direction r = f.getClockWise();
                    BlockPos base = p.blockPosition().relative(f, 3);
                    int placed = 0;
                    for (int w = -3; w <= 3; w++) {
                        for (int h = 0; h < 4; h++) {
                            if (TempBlocks.place(c.level(), base.relative(r, w).above(h), Blocks.PACKED_ICE.defaultBlockState(), 400)) placed++;
                        }
                    }
                    if (placed == 0) return false;
                    c.level().sendParticles(ParticleTypes.SNOWFLAKE, base.getX() + 0.5, base.getY() + 1.5, base.getZ() + 0.5, 60, 2.5, 1.5, 0.5, 0.05);
                    sound(c.level(), p.position(), SoundEvents.GLASS_BREAK, 1.2f, 0.5f);
                    return true;
                }),
            new Ability("Glacier Path", Items.BLUE_ICE, 8, 30, 400,
                "A rushing glacier: freezes enemies ahead, bridges gaps with ice and boosts your speed.", c -> {
                    ServerPlayer p = c.player();
                    Direction f = p.getDirection();
                    Direction r = f.getClockWise();
                    Set<UUID> seen = new HashSet<>();
                    for (int i = 1; i <= 18; i++) {
                        for (int w = -1; w <= 1; w++) {
                            BlockPos bp = p.blockPosition().relative(f, i).relative(r, w).below();
                            TempBlocks.place(c.level(), bp, Blocks.ICE.defaultBlockState(), 160);
                        }
                        Vec3 pos = p.position().add(f.getStepX() * i, 1, f.getStepZ() * i);
                        c.level().sendParticles(ParticleTypes.SNOWFLAKE, pos.x, pos.y - 0.5, pos.z, 6, 0.8, 0.2, 0.8, 0.02);
                        for (LivingEntity e : near(p, pos, 2.0)) {
                            if (seen.add(e.getUUID())) {
                                hit(p, e, c.dmg(6));
                                debuff(e, MobEffects.MOVEMENT_SLOWDOWN, 80, 3);
                                e.setTicksFrozen(260);
                            }
                        }
                    }
                    buff(p, MobEffects.MOVEMENT_SPEED, 100, 2);
                    sound(c.level(), p.position(), SoundEvents.GLASS_BREAK, 1f, 0.7f);
                    return true;
                }),
            new Ability("Flashfreeze Heatwave", Items.FIRE_CHARGE, 13, 55, 900,
                "Flash-freeze everything around you, then detonate it with a wave of heat.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 center = p.position().add(0, 1, 0);
                    for (LivingEntity e : near(p, center, 9)) {
                        e.setTicksFrozen(400);
                        debuff(e, MobEffects.MOVEMENT_SLOWDOWN, 60, 4);
                        hit(p, e, c.dmg(8));
                    }
                    c.level().sendParticles(ParticleTypes.SNOWFLAKE, center.x, center.y, center.z, 150, 4, 1.5, 4, 0.1);
                    float heat = c.dmg(12);
                    Scheduler.later(25, () -> {
                        if (!p.isAlive()) return;
                        c.level().sendParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 150, 4, 1.5, 4, 0.1);
                        c.level().sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
                        sound(c.level(), center, SoundEvents.GENERIC_EXPLODE, 1.5f, 0.8f);
                        for (LivingEntity e : near(p, center, 9)) {
                            hit(p, e, heat);
                            e.setSecondsOnFire(6);
                            knock(e, center, 1.6, 0.5);
                        }
                    });
                    sound(c.level(), center, SoundEvents.GLASS_BREAK, 1.5f, 0.4f);
                    return true;
                }));
    }

    public static Quirk hellflame() {
        return new Quirk("hellflame", "Hellflame", "Emitter",
            "Blue-hot flames that grow stronger the more they burn you. The number-one hero's fire.",
            QuirkRarity.EPIC, 0xE8590C,
            (p, lvl) -> buff(p, MobEffects.FIRE_RESISTANCE, 60, 0),
            new Ability("Hellflame Fist", Items.BLAZE_ROD, 1, 12, 30,
                "A flaming punch that ignites your target.", c -> {
                    LivingEntity t = target(c.player(), 4.5);
                    if (t == null) return false;
                    hit(c.player(), t, c.dmg(8));
                    t.setSecondsOnFire(8);
                    knock(t, c.player().position(), 1.2, 0.3);
                    c.level().sendParticles(ParticleTypes.FLAME, center(t).x, center(t).y, center(t).z, 25, 0.4, 0.4, 0.4, 0.1);
                    impact(c.level(), center(t));
                    return true;
                }),
            new Ability("Flashfire Fist", Items.FIRE_CHARGE, 4, 22, 160,
                "A blast of compressed flame fired from your fist in a wide cone.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), ParticleTypes.SOUL_FIRE_FLAME, from, from.add(c.look().scale(10)), 0.45);
                    for (LivingEntity e : cone(p, 10, 50)) {
                        hit(p, e, c.dmg(9));
                        e.setSecondsOnFire(6);
                        knock(e, p.position(), 1.0, 0.2);
                    }
                    sound(c.level(), p.position(), SoundEvents.FIRECHARGE_USE, 1.3f, 0.7f);
                    return true;
                }),
            new Ability("Prominence Burn", Items.MAGMA_BLOCK, 8, 40, 500,
                "A colossal beam of flame that scorches everything in a 22-block line.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.getEyePosition().subtract(0, 0.2, 0);
                    Vec3 dir = c.look();
                    Set<UUID> seen = new HashSet<>();
                    for (double t = 1; t <= 22; t += 1) {
                        Vec3 pos = from.add(dir.scale(t));
                        if (solid(c.level(), pos)) break;
                        c.level().sendParticles(ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y, pos.z, 6, 0.5, 0.5, 0.5, 0.02);
                        c.level().sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 4, 0.4, 0.4, 0.4, 0.02);
                        for (LivingEntity e : near(p, pos, 1.8)) {
                            if (seen.add(e.getUUID())) {
                                hit(p, e, c.dmg(15));
                                e.setSecondsOnFire(10);
                            }
                        }
                    }
                    sound(c.level(), p.position(), SoundEvents.BLAZE_SHOOT, 1.5f, 0.5f);
                    return true;
                }),
            new Ability("Hellflame Inferno", Items.LAVA_BUCKET, 13, 55, 900,
                "Explode into a sphere of hellfire that engulfs everything around you.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 center = p.position().add(0, 1, 0);
                    c.level().sendParticles(ParticleTypes.LAVA, center.x, center.y, center.z, 80, 4, 1.5, 4, 0.2);
                    c.level().sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 2, 2, 0.5, 2, 0);
                    sound(c.level(), center, SoundEvents.GENERIC_EXPLODE, 1.5f, 0.6f);
                    for (LivingEntity e : near(p, center, 9)) {
                        hit(p, e, c.dmg(20));
                        e.setSecondsOnFire(12);
                        knock(e, center, 1.8, 0.5);
                    }
                    buff(p, MobEffects.FIRE_RESISTANCE, 200, 0);
                    return true;
                }));
    }

    public static Quirk electrification() {
        return new Quirk("electrification", "Electrification", "Emitter",
            "Discharge thousands of volts. Shocking - but overdo it and your brain fries.",
            QuirkRarity.UNCOMMON, 0xFFE066,
            (p, lvl) -> { if (lvl >= 8) buff(p, MobEffects.MOVEMENT_SPEED, 60, 0); },
            new Ability("Zap", Items.COPPER_INGOT, 1, 10, 20,
                "A quick bolt that shocks and slows one target.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity t = target(p, 10);
                    if (t == null) return false;
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), ParticleTypes.ELECTRIC_SPARK, from, center(t), 0.4);
                    hit(p, t, c.dmg(5));
                    debuff(t, MobEffects.MOVEMENT_SLOWDOWN, 40, 1);
                    sound(c.level(), center(t), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.3f, 2f);
                    return true;
                }),
            new Ability("Chain Lightning", Items.CHAIN, 4, 22, 160,
                "Lightning that leaps between up to five enemies.", c -> {
                    ServerPlayer p = c.player();
                    LivingEntity cur = target(p, 10);
                    if (cur == null) return false;
                    Set<UUID> seen = new HashSet<>();
                    Vec3 prev = p.getEyePosition().subtract(0, 0.3, 0);
                    float dmg = c.dmg(7);
                    for (int i = 0; i < 5 && cur != null; i++) {
                        seen.add(cur.getUUID());
                        line(c.level(), ParticleTypes.ELECTRIC_SPARK, prev, center(cur), 0.4);
                        hit(p, cur, dmg);
                        debuff(cur, MobEffects.MOVEMENT_SLOWDOWN, 40, 1);
                        prev = center(cur);
                        dmg *= 0.85f;
                        LivingEntity next = null;
                        double best = Double.MAX_VALUE;
                        for (LivingEntity e : near(p, prev, 6)) {
                            if (seen.contains(e.getUUID())) continue;
                            double d = center(e).distanceToSqr(prev);
                            if (d < best) { best = d; next = e; }
                        }
                        cur = next;
                    }
                    sound(c.level(), p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.5f, 1.6f);
                    return true;
                }),
            new Ability("Static Field", Items.REDSTONE, 8, 35, 600,
                "Surround yourself with crackling static that shocks anything nearby for 6 seconds.", c -> {
                    ServerPlayer p = c.player();
                    float dmg = c.dmg(3);
                    Scheduler.repeat(10, 12, i -> {
                        if (!p.isAlive()) return;
                        Vec3 ctr = p.position().add(0, 1, 0);
                        ring(c.level(), ParticleTypes.ELECTRIC_SPARK, p.position().add(0, 0.5 + (i % 3) * 0.5, 0), 3.0, 20);
                        for (LivingEntity e : near(p, ctr, 6)) {
                            hit(p, e, dmg);
                            debuff(e, MobEffects.MOVEMENT_SLOWDOWN, 20, 0);
                        }
                    });
                    sound(c.level(), p.position(), SoundEvents.BEACON_ACTIVATE, 1f, 2f);
                    return true;
                }),
            new Ability("Indiscriminate Discharge", Items.LIGHTNING_ROD, 13, 60, 1000,
                "Release everything. Massive area shock - and your brain pays the price.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 ctr = p.position().add(0, 1, 0);
                    bolt(c.level(), p.position());
                    for (LivingEntity e : near(p, ctr, 11)) {
                        bolt(c.level(), e.position());
                        hit(p, e, c.dmg(18));
                        debuff(e, MobEffects.MOVEMENT_SLOWDOWN, 80, 3);
                        debuff(e, MobEffects.WEAKNESS, 80, 1);
                    }
                    debuff(p, MobEffects.MOVEMENT_SLOWDOWN, 100, 1);
                    debuff(p, MobEffects.WEAKNESS, 100, 1);
                    sound(c.level(), ctr, SoundEvents.LIGHTNING_BOLT_THUNDER, 1.5f, 1f);
                    return true;
                }));
    }

    public static Quirk decay() {
        return new Quirk("decay", "Decay", "Emitter",
            "Everything you touch crumbles to dust. Five fingers, no mercy.",
            QuirkRarity.EPIC, 0x8E9AA3,
            null,
            new Ability("Decay Touch", Items.WITHER_ROSE, 1, 12, 40,
                "Touch a target to rot it from within.", c -> {
                    LivingEntity t = target(c.player(), 4.5);
                    if (t == null) return false;
                    hit(c.player(), t, c.dmg(5));
                    debuff(t, MobEffects.WITHER, 100, 1);
                    c.level().sendParticles(ParticleTypes.ASH, center(t).x, center(t).y, center(t).z, 30, 0.4, 0.5, 0.4, 0.05);
                    sound(c.level(), center(t), SoundEvents.WITHER_SHOOT, 0.6f, 1.6f);
                    return true;
                }),
            new Ability("Five-Finger Decay", Items.SKELETON_SKULL, 4, 25, 300,
                "A full five-finger grip: lethal wither, weakness and hunger.", c -> {
                    LivingEntity t = target(c.player(), 4.5);
                    if (t == null) return false;
                    hit(c.player(), t, c.dmg(6));
                    debuff(t, MobEffects.WITHER, 200, 2);
                    debuff(t, MobEffects.WEAKNESS, 200, 1);
                    debuff(t, MobEffects.HUNGER, 200, 1);
                    c.level().sendParticles(ParticleTypes.ASH, center(t).x, center(t).y, center(t).z, 60, 0.5, 0.6, 0.5, 0.08);
                    decayBlocks(c.level(), t.blockPosition(), 2);
                    sound(c.level(), center(t), SoundEvents.WITHER_SHOOT, 0.8f, 1.2f);
                    return true;
                }),
            new Ability("Decay Wave", Items.ROTTEN_FLESH, 8, 35, 450,
                "Slam the ground and send a wave of decay across a wide cone.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.position().add(0, 0.3, 0);
                    line(c.level(), ParticleTypes.ASH, from, from.add(c.look().scale(9)), 0.4);
                    for (LivingEntity e : cone(p, 9, 45)) {
                        hit(p, e, c.dmg(10));
                        debuff(e, MobEffects.WITHER, 120, 1);
                    }
                    decayBlocks(c.level(), BlockPos.containing(p.position().add(c.look().scale(4))), 4);
                    sound(c.level(), p.position(), SoundEvents.WITHER_SHOOT, 1f, 0.8f);
                    return true;
                }),
            new Ability("Total Decay", Items.WITHER_SKELETON_SKULL, 13, 55, 900,
                "Unleash decay in all directions - everything nearby rots away.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 ctr = p.position().add(0, 1, 0);
                    c.level().sendParticles(ParticleTypes.ASH, ctr.x, ctr.y, ctr.z, 250, 5, 2, 5, 0.1);
                    c.level().sendParticles(ParticleTypes.LARGE_SMOKE, ctr.x, ctr.y, ctr.z, 60, 5, 2, 5, 0.05);
                    for (LivingEntity e : near(p, ctr, 10)) {
                        hit(p, e, c.dmg(16));
                        debuff(e, MobEffects.WITHER, 160, 3);
                        debuff(e, MobEffects.HUNGER, 160, 1);
                    }
                    decayBlocks(c.level(), p.blockPosition(), 7);
                    sound(c.level(), ctr, SoundEvents.WITHER_SPAWN, 0.6f, 1.5f);
                    return true;
                }));
    }
}
