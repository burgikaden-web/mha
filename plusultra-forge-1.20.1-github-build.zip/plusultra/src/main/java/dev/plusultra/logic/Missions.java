package dev.plusultra.logic;

import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.data.HeroData;
import dev.plusultra.data.Mission;
import dev.plusultra.registry.ModItems;
import dev.plusultra.util.Fx;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.items.ItemHandlerHelper;

/** Mission generation, progress tracking, rewards and villain ambushes. */
public final class Missions {
    public static final String VILLAIN_TAG = "plusultra_villain";
    private static final String[] VILLAIN_NAMES = {"Street Thug", "Villain Recruit", "Hideout Goon", "Rogue Villain"};

    private Missions() {}

    public static Mission generate(RandomSource r, int rank) {
        Mission m = new Mission();
        Mission.Type[] types = Mission.Type.values();
        m.type = types[r.nextInt(types.length)];
        m.tier = r.nextInt(Math.min(4, rank + 2));
        int t = m.tier;
        m.target = switch (m.type) {
            case KILL_ANY -> 10 + t * 8;
            case KILL_ZOMBIE -> 8 + t * 6;
            case KILL_SKELETON -> 6 + t * 5;
            case KILL_CREEPER -> 4 + t * 3;
            case KILL_SPIDER -> 6 + t * 4;
            case USE_ABILITIES -> 15 + t * 10;
            case DEAL_DAMAGE -> 150 + t * 150;
            case VILLAINS -> 3 + t * 2;
        };
        double mult = PlusUltraConfig.MISSION_MULT.get();
        m.points = (int) ((10 + t * 15 + m.target / 4) * mult);
        m.xp = (int) ((40 + t * 60 + m.target / 2) * mult);
        return m;
    }

    public static void fillOffers(HeroData d, RandomSource r) {
        int rank = Progression.rank(d.heroPoints);
        while (d.offers.size() < HeroData.MAX_OFFERS) d.offers.add(generate(r, rank));
        d.dirty = true;
    }

    public static void progress(ServerPlayer p, HeroData d, Mission.Type type, int amount) {
        for (Mission m : d.active) {
            if (m.type != type || m.complete()) continue;
            m.progress = Math.min(m.target, m.progress + amount);
            d.dirty = true;
            if (m.complete()) {
                p.sendSystemMessage(Component.literal("Mission complete: " + m.type.title + " - open the Hero Menu (H) to claim your reward!")
                        .withStyle(ChatFormatting.GREEN));
                p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8f, 1.5f);
            }
        }
    }

    public static void onKill(ServerPlayer p, HeroData d, LivingEntity victim) {
        boolean villain = victim.getTags().contains(VILLAIN_TAG);
        if (victim instanceof Enemy || villain) progress(p, d, Mission.Type.KILL_ANY, 1);
        if (victim instanceof Zombie) progress(p, d, Mission.Type.KILL_ZOMBIE, 1);
        if (victim instanceof AbstractSkeleton) progress(p, d, Mission.Type.KILL_SKELETON, 1);
        if (victim instanceof Creeper) progress(p, d, Mission.Type.KILL_CREEPER, 1);
        if (victim instanceof Spider) progress(p, d, Mission.Type.KILL_SPIDER, 1);
        if (villain) progress(p, d, Mission.Type.VILLAINS, 1);
    }

    /** Client request: 0 = accept offer, 1 = claim reward, 2 = abandon, 3 = reroll offers. */
    public static void action(ServerPlayer p, int action, int idx) {
        HeroData d = HeroData.get(p);
        switch (action) {
            case 0 -> accept(p, d, idx);
            case 1 -> claim(p, d, idx);
            case 2 -> {
                if (idx >= 0 && idx < d.active.size()) {
                    d.active.remove(idx);
                    d.dirty = true;
                }
            }
            case 3 -> {
                d.offers.clear();
                fillOffers(d, p.getRandom());
            }
            default -> { }
        }
    }

    private static void accept(ServerPlayer p, HeroData d, int idx) {
        if (idx < 0 || idx >= d.offers.size() || d.active.size() >= HeroData.MAX_ACTIVE) return;
        Mission m = d.offers.get(idx);
        if (m.type == Mission.Type.VILLAINS) {
            if (p.serverLevel().getDifficulty() == Difficulty.PEACEFUL) {
                Fx.msg(p, "Villains won't appear on Peaceful difficulty.");
                return;
            }
            spawnVillains(p, m.target);
        }
        d.offers.remove(idx);
        d.active.add(m);
        fillOffers(d, p.getRandom());
        p.sendSystemMessage(Component.literal("Mission accepted: " + m.type.title + " - " + m.description()).withStyle(ChatFormatting.AQUA));
    }

    private static void claim(ServerPlayer p, HeroData d, int idx) {
        if (idx < 0 || idx >= d.active.size()) return;
        Mission m = d.active.get(idx);
        if (!m.complete()) return;
        d.active.remove(idx);
        d.missionsCompleted++;
        Progression.addPoints(p, d, m.points);
        Progression.giveXp(p, d, m.xp);
        ItemHandlerHelper.giveItemToPlayer(p, new ItemStack(Items.EMERALD, 2 + m.tier * 3));
        if (m.tier >= 1) ItemHandlerHelper.giveItemToPlayer(p, new ItemStack(ModItems.STAMINA_DRINK.get(), 1 + m.tier / 2));
        if (m.tier >= 3 && p.getRandom().nextFloat() < 0.3f) {
            ItemHandlerHelper.giveItemToPlayer(p, new ItemStack(ModItems.AWAKENING_SCROLL.get()));
            p.sendSystemMessage(Component.literal("Bonus reward: an Awakening Scroll!").withStyle(ChatFormatting.LIGHT_PURPLE));
        }
        p.sendSystemMessage(Component.literal("Reward claimed: +" + m.points + " hero points, +" + m.xp + " mastery XP").withStyle(ChatFormatting.GOLD));
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1f, 1f);
        d.dirty = true;
    }

    private static void spawnVillains(ServerPlayer p, int count) {
        ServerLevel l = p.serverLevel();
        EntityType<?>[] pool = {EntityType.VINDICATOR, EntityType.PILLAGER, EntityType.WITCH};
        for (int i = 0; i < count; i++) {
            Entity ent = pool[i % pool.length].create(l);
            if (!(ent instanceof Mob mob)) continue;
            Vec3 s = Fx.randomSpot(l, p.position(), 14, 22);
            mob.moveTo(s.x, s.y, s.z, p.getRandom().nextFloat() * 360f, 0f);
            mob.setCustomName(Component.literal(VILLAIN_NAMES[p.getRandom().nextInt(VILLAIN_NAMES.length)]).withStyle(ChatFormatting.RED));
            mob.setCustomNameVisible(true);
            mob.addTag(VILLAIN_TAG);
            mob.setPersistenceRequired();
            mob.finalizeSpawn(l, l.getCurrentDifficultyAt(mob.blockPosition()), MobSpawnType.EVENT, null, null);
            mob.setTarget(p);
            l.addFreshEntity(mob);
        }
        p.sendSystemMessage(Component.literal("Villains are ambushing you! Defend yourself!").withStyle(ChatFormatting.RED));
    }
}
