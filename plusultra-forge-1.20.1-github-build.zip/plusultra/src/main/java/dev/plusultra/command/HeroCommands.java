package dev.plusultra.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import dev.plusultra.data.HeroData;
import dev.plusultra.logic.Missions;
import dev.plusultra.logic.Progression;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.Quirks;
import java.util.Collection;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** /plusultra ... (admin commands need permission level 2; /plusultra info is for everyone). */
public final class HeroCommands {
    private static final SuggestionProvider<CommandSourceStack> QUIRKS =
            (ctx, b) -> SharedSuggestionProvider.suggest(Quirks.ids(), b);

    private HeroCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> disp) {
        disp.register(Commands.literal("plusultra")
            .then(Commands.literal("info").executes(c -> info(c.getSource(), c.getSource().getPlayerOrException())))
            .then(Commands.literal("quirk").requires(s -> s.hasPermission(2))
                .then(Commands.literal("set").then(Commands.argument("targets", EntityArgument.players())
                    .then(Commands.argument("quirk", StringArgumentType.word()).suggests(QUIRKS).executes(c -> {
                        Quirk q = Quirks.get(StringArgumentType.getString(c, "quirk"));
                        if (q == null) {
                            c.getSource().sendFailure(Component.literal("Unknown quirk. Try tab-completion."));
                            return 0;
                        }
                        return each(c, p -> Progression.awaken(p, HeroData.get(p), q), "Set quirk to " + q.name);
                    }))))
                .then(Commands.literal("random").then(Commands.argument("targets", EntityArgument.players()).executes(c ->
                    each(c, p -> {
                        HeroData d = HeroData.get(p);
                        Progression.awaken(p, d, Quirks.roll(p.getRandom(), d.quirkId, true));
                    }, "Awakened a random quirk"))))
                .then(Commands.literal("clear").then(Commands.argument("targets", EntityArgument.players()).executes(c ->
                    each(c, p -> {
                        HeroData d = HeroData.get(p);
                        d.quirkId = "";
                        d.dirty = true;
                    }, "Cleared quirk")))))
            .then(Commands.literal("mastery").requires(s -> s.hasPermission(2))
                .then(Commands.literal("level").then(Commands.argument("targets", EntityArgument.players())
                    .then(Commands.argument("level", IntegerArgumentType.integer(1, HeroData.MAX_LEVEL)).executes(c -> {
                        int lvl = IntegerArgumentType.getInteger(c, "level");
                        return each(c, p -> {
                            HeroData d = HeroData.get(p);
                            if (d.quirk() == null) return;
                            d.xp.put(d.quirkId, Progression.xpToReach(lvl));
                            d.dirty = true;
                        }, "Set mastery level to " + lvl);
                    }))))
                .then(Commands.literal("addxp").then(Commands.argument("targets", EntityArgument.players())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(1)).executes(c -> {
                        int amt = IntegerArgumentType.getInteger(c, "amount");
                        return each(c, p -> Progression.giveXp(p, HeroData.get(p), amt), "Added " + amt + " mastery XP");
                    })))))
            .then(Commands.literal("points").requires(s -> s.hasPermission(2))
                .then(Commands.literal("add").then(Commands.argument("targets", EntityArgument.players())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(1)).executes(c -> {
                        int amt = IntegerArgumentType.getInteger(c, "amount");
                        return each(c, p -> Progression.addPoints(p, HeroData.get(p), amt), "Added " + amt + " hero points");
                    })))))
            .then(Commands.literal("stamina").requires(s -> s.hasPermission(2))
                .then(Commands.literal("refill").then(Commands.argument("targets", EntityArgument.players()).executes(c ->
                    each(c, p -> {
                        HeroData d = HeroData.get(p);
                        d.stamina = d.maxStamina();
                        d.dirty = true;
                    }, "Refilled stamina")))))
            .then(Commands.literal("missions").requires(s -> s.hasPermission(2))
                .then(Commands.literal("reroll").then(Commands.argument("targets", EntityArgument.players()).executes(c ->
                    each(c, p -> Missions.action(p, 3, 0), "Rerolled mission offers"))))));
    }

    private static int each(CommandContext<CommandSourceStack> c, Consumer<ServerPlayer> r, String msg) throws CommandSyntaxException {
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(c, "targets");
        for (ServerPlayer p : targets) r.accept(p);
        c.getSource().sendSuccess(() -> Component.literal(msg + " (" + targets.size() + " player(s))"), true);
        return targets.size();
    }

    private static int info(CommandSourceStack src, ServerPlayer p) {
        HeroData d = HeroData.get(p);
        Quirk q = d.quirk();
        String quirk = q == null ? "none" : q.name + " (Lv " + d.level() + " " + Progression.masteryTitle(d.level()) + ")";
        src.sendSuccess(() -> Component.literal("Quirk: " + quirk + " | Rank: " + Progression.RANKS[Progression.rank(d.heroPoints)]
                + " (" + d.heroPoints + " pts) | Missions done: " + d.missionsCompleted + " | Skill points: " + d.skillPoints), false);
        return 1;
    }
}
