package dev.plusultra.quirk.impl;

import static dev.plusultra.util.Fx.*;

import dev.plusultra.quirk.Ability;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.QuirkRarity;
import dev.plusultra.util.Scheduler;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/** One For All, Hardening, Explosion, Engine. */
public final class PowerQuirks {
    private PowerQuirks() {}

    public static Quirk oneForAll() {
        return new Quirk("one_for_all", "One For All", "Transmission",
            "Nine generations of stockpiled power. Raw strength that reshapes the battlefield.",
            QuirkRarity.LEGENDARY, 0x3DDC6B,
            (p, lvl) -> {
                if (lvl >= 5) buff(p, MobEffects.DAMAGE_BOOST, 60, 0);
                if (lvl >= 10) buff(p, MobEffects.JUMP, 60, 0);
                if (lvl >= 15) buff(p, MobEffects.MOVEMENT_SPEED, 60, 0);
            },
            new Ability("Detroit Smash", Items.IRON_SWORD, 1, 14, 30,
                "A crushing close-range punch that launches the target.", c -> {
                    LivingEntity t = target(c.player(), 4.5);
                    if (t == null) return false;
                    hit(c.player(), t, c.dmg(10));
                    knock(t, c.player().position(), 1.8, 0.5);
                    impact(c.level(), center(t));
                    return true;
                }),
            new Ability("Full Cowl", Items.GLOWSTONE_DUST, 4, 30, 500,
                "Spread power through your whole body: speed, strength and leaping power.", c -> {
                    ServerPlayer p = c.player();
                    buff(p, MobEffects.MOVEMENT_SPEED, 400, 1);
                    buff(p, MobEffects.DAMAGE_BOOST, 400, 0);
                    buff(p, MobEffects.JUMP, 400, 1);
                    ring(c.level(), dust(0x3DDC6B, 1.3f), p.position().add(0, 0.1, 0), 1.2, 24);
                    sound(c.level(), p.position(), SoundEvents.BEACON_ACTIVATE, 1f, 1.6f);
                    return true;
                }),
            new Ability("Delaware Smash", Items.BOW, 8, 35, 180,
                "Flick a shockwave of air pressure that flattens everything ahead.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.getEyePosition().subtract(0, 0.3, 0);
                    line(c.level(), ParticleTypes.CLOUD, from, from.add(c.look().scale(9)), 0.6);
                    for (LivingEntity e : cone(p, 9, 38)) {
                        hit(p, e, c.dmg(14));
                        knock(e, p.position(), 2.2, 0.7);
                    }
                    sound(c.level(), p.position(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.5f, 0.5f);
                    return true;
                }),
            new Ability("United States of Smash", Items.NETHER_STAR, 13, 70, 1200,
                "A full-power release. Devastating - but it hurts you.", c -> {
                    ServerPlayer p = c.player();
                    blast(p, p.position().add(0, 1, 0), 10f, c.dmg(28), 2.6);
                    c.level().sendParticles(ParticleTypes.SONIC_BOOM, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0, 0, 0);
                    selfHurt(p, 3f);
                    debuff(p, MobEffects.WEAKNESS, 200, 0);
                    return true;
                }));
    }

    public static Quirk hardening() {
        return new Quirk("hardening", "Hardening", "Transformation",
            "Harden your body into an unbreakable fortress and shatter foes with fists of rock.",
            QuirkRarity.COMMON, 0xE04A3F,
            (p, lvl) -> { if (lvl >= 6) buff(p, MobEffects.DAMAGE_RESISTANCE, 60, 0); },
            new Ability("Hardened Fist", Items.COBBLESTONE, 1, 12, 25,
                "Two rapid, rock-hard punches against a nearby target.", c -> {
                    LivingEntity t = target(c.player(), 4.5);
                    if (t == null) return false;
                    hit(c.player(), t, c.dmg(5));
                    Scheduler.later(4, () -> {
                        if (t.isAlive()) {
                            hit(c.player(), t, c.dmg(5));
                            knock(t, c.player().position(), 1.0, 0.25);
                            impact(c.level(), center(t));
                        }
                    });
                    impact(c.level(), center(t));
                    return true;
                }),
            new Ability("Harden", Items.IRON_CHESTPLATE, 4, 25, 500,
                "Stone-skinned: big damage resistance for 15 seconds.", c -> {
                    buff(c.player(), MobEffects.DAMAGE_RESISTANCE, 300, 1);
                    c.level().sendParticles(ParticleTypes.CRIT, c.player().getX(), c.player().getY() + 1, c.player().getZ(), 30, 0.5, 0.8, 0.5, 0.2);
                    sound(c.level(), c.player().position(), SoundEvents.ANVIL_LAND, 0.8f, 1.2f);
                    return true;
                }),
            new Ability("Red Riot Unbreakable", Items.NETHERITE_CHESTPLATE, 8, 40, 900,
                "Maximum hardness: huge resistance, absorption and strength, at the cost of mobility.", c -> {
                    ServerPlayer p = c.player();
                    buff(p, MobEffects.DAMAGE_RESISTANCE, 240, 2);
                    buff(p, MobEffects.ABSORPTION, 240, 2);
                    buff(p, MobEffects.DAMAGE_BOOST, 240, 0);
                    debuff(p, MobEffects.MOVEMENT_SLOWDOWN, 240, 0);
                    ring(c.level(), dust(0xE04A3F, 1.4f), p.position().add(0, 0.1, 0), 1.0, 20);
                    sound(c.level(), p.position(), SoundEvents.IRON_GOLEM_REPAIR, 1.2f, 0.6f);
                    return true;
                }),
            new Ability("Fang Rush", Items.DIAMOND_SWORD, 13, 45, 400,
                "Charge forward with a jagged hardened body, ramming everything in your path.", c -> {
                    dashAttack(c, 2.2, 0.15, 9, 2.0, c.dmg(11), 1.4, ParticleTypes.CRIT);
                    sound(c.level(), c.player().position(), SoundEvents.RAVAGER_ROAR, 0.8f, 1.4f);
                    return true;
                }));
    }

    public static Quirk explosion() {
        return new Quirk("explosion", "Explosion", "Emitter",
            "Sweat that explodes like nitroglycerin. The more you sweat, the harder it hits.",
            QuirkRarity.RARE, 0xFF8A1F,
            (p, lvl) -> { if (lvl >= 3) buff(p, MobEffects.DIG_SPEED, 60, 0); },
            new Ability("Explosion", Items.GUNPOWDER, 1, 14, 30,
                "Detonate a blast at the point you are looking at. Kicks you back slightly.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 at = aim(p, 7);
                    Vec3 back = c.look().scale(-0.35);
                    blast(p, at, 3.2f, c.dmg(9), 1.1);
                    push(p, p.getDeltaMovement().add(back.x, 0.1, back.z));
                    return true;
                }),
            new Ability("Stun Grenade", Items.FIREWORK_STAR, 4, 20, 300,
                "A blinding flash and bang that blinds and slows everyone nearby.", c -> {
                    Vec3 pos = c.center();
                    for (LivingEntity e : near(c.player(), pos, 9)) {
                        debuff(e, MobEffects.BLINDNESS, 100, 0);
                        debuff(e, MobEffects.MOVEMENT_SLOWDOWN, 80, 1);
                        hit(c.player(), e, c.dmg(2));
                    }
                    c.level().sendParticles(ParticleTypes.FLASH, pos.x, pos.y + 0.5, pos.z, 3, 1, 1, 1, 0);
                    sound(c.level(), pos, SoundEvents.FIREWORK_ROCKET_BLAST, 1.5f, 0.8f);
                    return true;
                }),
            new Ability("Howitzer Impact", Items.TNT, 8, 40, 500,
                "Spin and rocket forward, then detonate in a huge blast where you land.", c -> {
                    ServerPlayer p = c.player();
                    dashAttack(c, 1.9, 0.35, 14, 0, 0, 0, ParticleTypes.FLAME);
                    float dmg = c.dmg(16);
                    Scheduler.later(15, () -> {
                        if (p.isAlive()) blast(p, p.position().add(0, 0.5, 0), 5f, dmg, 2.0);
                    });
                    return true;
                }),
            new Ability("AP Shot: Auto-Cannon", Items.FIREWORK_ROCKET, 13, 50, 600,
                "Fire a piercing beam of compressed explosions up to 25 blocks.", c -> {
                    ServerPlayer p = c.player();
                    Vec3 from = p.getEyePosition();
                    Vec3 dir = c.look();
                    Set<UUID> seen = new HashSet<>();
                    Vec3 end = from;
                    for (double t = 1.5; t <= 25; t += 1.5) {
                        Vec3 pos = from.add(dir.scale(t));
                        if (solid(c.level(), pos)) break;
                        end = pos;
                        c.level().sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0.1, 0.1, 0.1, 0);
                        c.level().sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 4, 0.2, 0.2, 0.2, 0.02);
                        for (LivingEntity e : near(p, pos, 2.3)) {
                            if (seen.add(e.getUUID())) {
                                hit(p, e, c.dmg(12));
                                knock(e, from, 1.2, 0.3);
                            }
                        }
                    }
                    blast(p, end, 3.5f, c.dmg(8), 1.5);
                    push(p, p.getDeltaMovement().add(dir.x * -1.2, 0.15, dir.z * -1.2));
                    return true;
                }));
    }

    public static Quirk engine() {
        return new Quirk("engine", "Engine", "Mutant",
            "Engines in your calves let you tear across the map at breakneck speed.",
            QuirkRarity.COMMON, 0x2E86DE,
            (p, lvl) -> { if (lvl >= 3) buff(p, MobEffects.MOVEMENT_SPEED, 60, lvl >= 12 ? 1 : 0); },
            new Ability("Recipro Burst", Items.IRON_BOOTS, 1, 20, 300,
                "Overclock your engines for a big speed boost.", c -> {
                    buff(c.player(), MobEffects.MOVEMENT_SPEED, 160, 2);
                    ring(c.level(), ParticleTypes.CLOUD, c.player().position().add(0, 0.1, 0), 1.0, 16);
                    sound(c.level(), c.player().position(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 1f, 1.2f);
                    return true;
                }),
            new Ability("Engine Dash", Items.SUGAR, 4, 22, 80,
                "A straight-line sprint that bowls enemies over.", c -> {
                    dashAttack(c, 2.6, 0.1, 8, 2.0, c.dmg(5), 0.8, ParticleTypes.CLOUD);
                    sound(c.level(), c.player().position(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 1f, 0.8f);
                    return true;
                }),
            new Ability("Recipro Extend", Items.DIAMOND_BOOTS, 8, 40, 700,
                "Extreme speed and leaping for 6 seconds. Your engines stall afterwards.", c -> {
                    ServerPlayer p = c.player();
                    buff(p, MobEffects.MOVEMENT_SPEED, 120, 4);
                    buff(p, MobEffects.JUMP, 120, 2);
                    Scheduler.later(120, () -> {
                        if (p.isAlive()) {
                            debuff(p, MobEffects.MOVEMENT_SLOWDOWN, 60, 1);
                            msg(p, "Engines stalled!");
                        }
                    });
                    sound(c.level(), p.position(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.3f, 0.6f);
                    return true;
                }),
            new Ability("Recipro Overdrive", Items.NETHERITE_BOOTS, 13, 60, 1100,
                "Redline! Insane speed and a trampling aura for 6 seconds, then a hard stall.", c -> {
                    ServerPlayer p = c.player();
                    buff(p, MobEffects.MOVEMENT_SPEED, 120, 6);
                    buff(p, MobEffects.JUMP, 120, 3);
                    float dmg = c.dmg(4);
                    Scheduler.repeat(4, 30, i -> {
                        if (!p.isAlive()) return;
                        for (LivingEntity e : near(p, p.position().add(0, 1, 0), 2.5)) {
                            hit(p, e, dmg);
                            knock(e, p.position(), 0.6, 0.2);
                        }
                        c.level().sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.5, p.getZ(), 8, 0.4, 0.3, 0.4, 0.05);
                    });
                    Scheduler.later(125, () -> {
                        if (p.isAlive()) {
                            debuff(p, MobEffects.MOVEMENT_SLOWDOWN, 100, 2);
                            debuff(p, MobEffects.WEAKNESS, 100, 0);
                            msg(p, "Engines overheated!");
                        }
                    });
                    sound(c.level(), p.position(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.5f, 0.5f);
                    return true;
                }));
    }
}
