package dev.plusultra.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;

/** Places blocks that automatically revert (ice walls, iron shields, ice bridges...). */
public final class TempBlocks {
    private record Entry(ServerLevel level, BlockPos pos, BlockState placed, BlockState original, long expire) {}

    private static final List<Entry> ENTRIES = new ArrayList<>();

    private TempBlocks() {}

    public static boolean place(ServerLevel level, BlockPos pos, BlockState state, int ticks) {
        BlockState cur = level.getBlockState(pos);
        if (!(cur.isAir() || cur.canBeReplaced())) return false;
        level.setBlock(pos, state, 3);
        ENTRIES.add(new Entry(level, pos.immutable(), state, cur, level.getGameTime() + ticks));
        return true;
    }

    public static void tick() {
        if (ENTRIES.isEmpty()) return;
        Iterator<Entry> it = ENTRIES.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (e.level.getGameTime() < e.expire) continue;
            if (!e.level.isLoaded(e.pos)) continue; // retry once the chunk is back
            if (e.level.getBlockState(e.pos) == e.placed) e.level.setBlock(e.pos, e.original, 3);
            it.remove();
        }
    }

    public static void revertAll() {
        for (Entry e : ENTRIES) {
            if (e.level.isLoaded(e.pos) && e.level.getBlockState(e.pos) == e.placed) {
                e.level.setBlock(e.pos, e.original, 3);
            }
        }
        ENTRIES.clear();
    }
}
