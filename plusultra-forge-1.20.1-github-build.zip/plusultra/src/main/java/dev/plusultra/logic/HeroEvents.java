package dev.plusultra.logic;

import dev.plusultra.PlusUltra;
import dev.plusultra.command.HeroCommands;
import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.data.HeroCaps;
import dev.plusultra.data.HeroData;
import dev.plusultra.data.Mission;
import dev.plusultra.network.ModNetwork;
import dev.plusultra.quirk.Quirk;
import dev.plusultra.quirk.Quirks;
import dev.plusultra.util.Fx;
import dev.plusultra.util.Scheduler;
import dev.plusultra.util.TempBlocks;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-side game logic wired to Forge events. */
@Mod.EventBusSubscriber(modid = PlusUltra.MODID)
public final class HeroEvents {
    private HeroEvents() {}

    // ------------------------------------------------------------------ capability

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) {
            HeroCaps.Provider prov = new HeroCaps.Provider();
            e.addCapability(new ResourceLocation(PlusUltra.MODID, "hero"), prov);
            e.addListener(prov::invalidate);
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        e.getOriginal().reviveCaps();
        HeroData old = HeroData.get(e.getOriginal());
        HeroData now = HeroData.get(e.getEntity());
        now.load(old.save());
        if (e.isWasDeath()) now.resetTransient();
        now.dirty = true;
        e.getOriginal().invalidateCaps();
    }

    // ------------------------------------------------------------------ join / respawn

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        HeroData d = HeroData.get(sp);
        if (sp.getPersistentData().getBoolean("plusultra_flight")) Fx.setFlight(sp, false);
        Missions.fillOffers(d, sp.getRandom());
        if (!d.awakened) {
            d.awakened = true;
            if (PlusUltraConfig.AUTO_AWAKEN.get() && d.quirkId.isEmpty()) {
                Progression.awaken(sp, d, Quirks.roll(sp.getRandom(), "", false));
            }
        }
        d.stamina = Math.max(d.stamina, 0f);
        d.dirty = true;
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        HeroData d = HeroData.get(sp);
        d.resetTransient();
    }

    /** The client rebuilds its player on dimension change, so it needs the hero data again. */
    @SubscribeEvent
    public static void changedDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) HeroData.get(sp).dirty = true;
    }

    // ------------------------------------------------------------------ per-tick

    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Player pl = e.player;
        HeroData d = HeroData.get(pl);
        boolean puEnded = d.tickTimers();
        if (!(pl instanceof ServerPlayer sp)) return;

        Quirk q = d.quirk();
        if (puEnded) AbilityManager.endPlusUltra(sp, d);

        float max = d.maxStamina();
        if (d.stamina < max) d.stamina = Math.min(max, d.stamina + d.regenPerTick());
        else if (d.stamina > max) d.stamina = max;

        if (q != null) {
            if (q.passive != null && sp.tickCount % 20 == 0) q.passive.tick(sp, d.level());
            if (d.plusUltraActive() && sp.tickCount % 3 == 0) {
                sp.serverLevel().sendParticles(Fx.dust(q.color, 1.2f), sp.getX(), sp.getY() + 1, sp.getZ(), 4, 0.4, 0.7, 0.4, 0);
                if (sp.tickCount % 9 == 0) {
                    sp.serverLevel().sendParticles(ParticleTypes.ELECTRIC_SPARK, sp.getX(), sp.getY() + 1, sp.getZ(), 3, 0.4, 0.7, 0.4, 0.1);
                }
            }
        }

        if (d.flightTicks > 0) {
            sp.fallDistance = 0;
            if (--d.flightTicks == 0) {
                Fx.setFlight(sp, false);
                Fx.buff(sp, MobEffects.SLOW_FALLING, 200, 0);
            }
        }

        if (d.dirty) {
            d.dirty = false;
            ModNetwork.sendFull(sp, d);
            d.lastSentStamina = d.stamina;
        } else if (sp.tickCount % 10 == 0 && needsLight(d)) {
            ModNetwork.sendLight(sp, d);
            d.lastSentStamina = d.stamina;
        }
    }

    private static boolean needsLight(HeroData d) {
        if (Math.abs(d.stamina - d.lastSentStamina) > 0.01f) return true;
        for (int c : d.cooldowns) if (c > 0) return true;
        return d.plusUltraTicks > 0 || d.plusUltraCooldown > 0;
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Scheduler.tick();
        TempBlocks.tick();
    }

    @SubscribeEvent
    public static void stopping(ServerStoppingEvent e) {
        TempBlocks.revertAll();
        Scheduler.clear();
    }

    // ------------------------------------------------------------------ combat / progress

    @SubscribeEvent
    public static void death(LivingDeathEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer sp) || e.getEntity() == sp) return;
        HeroData d = HeroData.get(sp);
        d.totalKills++;
        Missions.onKill(sp, d, e.getEntity());
        if (d.quirk() != null) {
            double xp = e.getEntity().getTags().contains(Missions.VILLAIN_TAG) ? 10 : 3;
            if (sp.level().getGameTime() - d.lastCastTick < 60) xp += 3; // quirk-kill bonus
            Progression.giveXpScaled(sp, d, xp);
        }
        if (e.getEntity().getTags().contains(Missions.VILLAIN_TAG)) Progression.addPoints(sp, d, 5);
        else if (e.getEntity() instanceof net.minecraft.world.entity.monster.Enemy) Progression.addPoints(sp, d, 1);
        d.dirty = true;
    }

    @SubscribeEvent
    public static void hurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            HeroData d = HeroData.get(sp);
            if (d.quirk() != null && d.stats[3] > 0) {
                e.setAmount(e.getAmount() * (1f - 0.02f * d.stats[3]));
            }
        }
    }

    @SubscribeEvent
    public static void damage(LivingDamageEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp && e.getEntity() != sp) {
            HeroData d = HeroData.get(sp);
            int amt = (int) e.getAmount();
            if (amt > 0) Missions.progress(sp, d, Mission.Type.DEAL_DAMAGE, amt);
        }
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        HeroCommands.register(e.getDispatcher());
    }
}
