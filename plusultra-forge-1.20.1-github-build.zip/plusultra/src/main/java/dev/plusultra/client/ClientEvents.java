package dev.plusultra.client;

import dev.plusultra.PlusUltra;
import dev.plusultra.network.ModNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ClientEvents {
    private ClientEvents() {}

    @Mod.EventBusSubscriber(modid = PlusUltra.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        private ModBus() {}

        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            for (KeyMapping k : Keys.ABILITY) e.register(k);
            e.register(Keys.PLUS_ULTRA);
            e.register(Keys.MENU);
        }

        @SubscribeEvent
        public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("hero_hud", HeroHud::render);
        }
    }

    @Mod.EventBusSubscriber(modid = PlusUltra.MODID, value = Dist.CLIENT)
    public static final class ForgeBus {
        private ForgeBus() {}

        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            while (Keys.MENU.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new HeroScreen());
            }
            if (mc.screen != null) return;
            for (int i = 0; i < Keys.ABILITY.length; i++) {
                while (Keys.ABILITY[i].consumeClick()) ModNetwork.CH.sendToServer(new ModNetwork.CastPacket(i));
            }
            while (Keys.PLUS_ULTRA.consumeClick()) ModNetwork.CH.sendToServer(new ModNetwork.PlusUltraPacket());
        }
    }
}
