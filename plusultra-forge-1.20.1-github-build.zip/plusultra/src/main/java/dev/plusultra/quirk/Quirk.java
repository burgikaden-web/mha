package dev.plusultra.quirk;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;

public final class Quirk {
    /** Called every second on the server while the quirk is equipped. */
    @FunctionalInterface
    public interface Passive {
        void tick(ServerPlayer player, int masteryLevel);
    }

    public final String id;
    public final String name;
    public final String type;
    public final String description;
    public final QuirkRarity rarity;
    public final int color;
    public final Passive passive;
    public final List<Ability> abilities;

    public Quirk(String id, String name, String type, String description, QuirkRarity rarity,
                 int color, Passive passive, Ability... abilities) {
        if (abilities.length != 4) throw new IllegalArgumentException(id + " must have exactly 4 abilities");
        this.id = id;
        this.name = name;
        this.type = type;
        this.description = description;
        this.rarity = rarity;
        this.color = color;
        this.passive = passive;
        this.abilities = List.of(abilities);
    }
}
