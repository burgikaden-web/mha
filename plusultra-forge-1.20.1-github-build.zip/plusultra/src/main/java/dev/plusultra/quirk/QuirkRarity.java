package dev.plusultra.quirk;

public enum QuirkRarity {
    COMMON("Common", 0xAAAAAA, 40),
    UNCOMMON("Uncommon", 0x55FF55, 28),
    RARE("Rare", 0x55AAFF, 18),
    EPIC("Epic", 0xAA55FF, 10),
    LEGENDARY("Legendary", 0xFFAA00, 3);

    public final String label;
    public final int color;
    public final int weight;

    QuirkRarity(String label, int color, int weight) {
        this.label = label;
        this.color = color;
        this.weight = weight;
    }
}
