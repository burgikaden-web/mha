package dev.plusultra.quirk;

import dev.plusultra.config.PlusUltraConfig;
import dev.plusultra.data.HeroData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/** Everything an ability needs to run. {@code power} already includes mastery, upgrades and Plus Ultra. */
public record AbilityContext(ServerPlayer player, ServerLevel level, HeroData data, float power) {
    public Vec3 eye() { return player.getEyePosition(); }
    public Vec3 look() { return player.getLookAngle(); }
    public Vec3 center() { return player.position().add(0, player.getBbHeight() * 0.5, 0); }
    public float dmg(float base) { return base * power * PlusUltraConfig.DAMAGE_MULT.get().floatValue(); }
}
