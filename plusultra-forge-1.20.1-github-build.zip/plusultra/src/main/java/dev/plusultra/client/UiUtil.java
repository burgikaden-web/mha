package dev.plusultra.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public final class UiUtil {
    private UiUtil() {}

    public static int lighten(int c, int amt) {
        int r = Math.min(255, ((c >> 16) & 255) + amt);
        int g = Math.min(255, ((c >> 8) & 255) + amt);
        int b = Math.min(255, (c & 255) + amt);
        return (r << 16) | (g << 8) | b;
    }

    public static int darken(int c, float f) {
        int r = (int) (((c >> 16) & 255) * f);
        int g = (int) (((c >> 8) & 255) * f);
        int b = (int) ((c & 255) * f);
        return (r << 16) | (g << 8) | b;
    }

    public static void card(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF1A1D26);
        g.fill(x, y, x + w, y + 1, 0xFF2F3447);
        g.renderOutline(x, y, w, h, 0xFF2B3040);
    }

    /** Horizontal progress bar with a vertical gradient. {@code color} is RGB without alpha. */
    public static void bar(GuiGraphics g, int x, int y, int w, int h, float ratio, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, 0xFF22252F);
        int fw = (int) (w * Mth.clamp(ratio, 0f, 1f));
        if (fw > 0) g.fillGradient(x, y, x + fw, y + h, 0xFF000000 | lighten(color, 55), 0xFF000000 | darken(color, 0.75f));
    }

    public static void scaled(GuiGraphics g, Font f, String s, int x, int y, float scale, int color) {
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(x, y, 0);
        ps.scale(scale, scale, 1f);
        g.drawString(f, s, 0, 0, color, true);
        ps.popPose();
    }
}
