package dev.plusultra.network;

import dev.plusultra.PlusUltra;
import dev.plusultra.client.ClientHooks;
import dev.plusultra.data.HeroData;
import dev.plusultra.logic.AbilityManager;
import dev.plusultra.logic.Missions;
import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(PlusUltra.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void init() {
        int id = 0;
        CH.registerMessage(id++, CastPacket.class, CastPacket::encode, CastPacket::decode, CastPacket::handle);
        CH.registerMessage(id++, PlusUltraPacket.class, PlusUltraPacket::encode, PlusUltraPacket::decode, PlusUltraPacket::handle);
        CH.registerMessage(id++, MissionPacket.class, MissionPacket::encode, MissionPacket::decode, MissionPacket::handle);
        CH.registerMessage(id++, UpgradePacket.class, UpgradePacket::encode, UpgradePacket::decode, UpgradePacket::handle);
        CH.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
        CH.registerMessage(id++, LightPacket.class, LightPacket::encode, LightPacket::decode, LightPacket::handle);
    }

    public static void sendFull(ServerPlayer p, HeroData d) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncPacket(d.save()));
    }

    public static void sendLight(ServerPlayer p, HeroData d) {
        CH.send(PacketDistributor.PLAYER.with(() -> p),
                new LightPacket(d.stamina, d.cooldowns.clone(), d.cooldownMax.clone(), d.plusUltraTicks, d.plusUltraCooldown));
    }

    private static void serverWork(Supplier<NetworkEvent.Context> sup, java.util.function.Consumer<ServerPlayer> r) {
        NetworkEvent.Context c = sup.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) r.accept(p);
        });
        c.setPacketHandled(true);
    }

    // ---------------------------------------------------------------- client -> server

    public static class CastPacket {
        public final int slot;
        public CastPacket(int slot) { this.slot = slot; }
        public static void encode(CastPacket m, FriendlyByteBuf b) { b.writeVarInt(m.slot); }
        public static CastPacket decode(FriendlyByteBuf b) { return new CastPacket(b.readVarInt()); }
        public static void handle(CastPacket m, Supplier<NetworkEvent.Context> s) {
            serverWork(s, p -> AbilityManager.cast(p, m.slot));
        }
    }

    public static class PlusUltraPacket {
        public PlusUltraPacket() { }
        public static void encode(PlusUltraPacket m, FriendlyByteBuf b) { }
        public static PlusUltraPacket decode(FriendlyByteBuf b) { return new PlusUltraPacket(); }
        public static void handle(PlusUltraPacket m, Supplier<NetworkEvent.Context> s) {
            serverWork(s, AbilityManager::plusUltra);
        }
    }

    public static class MissionPacket {
        public final int action, index;
        public MissionPacket(int action, int index) { this.action = action; this.index = index; }
        public static void encode(MissionPacket m, FriendlyByteBuf b) { b.writeVarInt(m.action); b.writeVarInt(m.index); }
        public static MissionPacket decode(FriendlyByteBuf b) { return new MissionPacket(b.readVarInt(), b.readVarInt()); }
        public static void handle(MissionPacket m, Supplier<NetworkEvent.Context> s) {
            serverWork(s, p -> Missions.action(p, m.action, m.index));
        }
    }

    public static class UpgradePacket {
        public final int stat;
        public UpgradePacket(int stat) { this.stat = stat; }
        public static void encode(UpgradePacket m, FriendlyByteBuf b) { b.writeVarInt(m.stat); }
        public static UpgradePacket decode(FriendlyByteBuf b) { return new UpgradePacket(b.readVarInt()); }
        public static void handle(UpgradePacket m, Supplier<NetworkEvent.Context> s) {
            serverWork(s, p -> AbilityManager.upgrade(p, m.stat));
        }
    }

    // ---------------------------------------------------------------- server -> client

    public static class SyncPacket {
        public final CompoundTag tag;
        public SyncPacket(CompoundTag tag) { this.tag = tag; }
        public static void encode(SyncPacket m, FriendlyByteBuf b) { b.writeNbt(m.tag); }
        public static SyncPacket decode(FriendlyByteBuf b) { return new SyncPacket(b.readNbt()); }
        public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.onSync(m.tag)));
            c.setPacketHandled(true);
        }
    }

    public static class LightPacket {
        public final float stamina;
        public final int[] cd, cdMax;
        public final int puTicks, puCooldown;

        public LightPacket(float stamina, int[] cd, int[] cdMax, int puTicks, int puCooldown) {
            this.stamina = stamina;
            this.cd = cd;
            this.cdMax = cdMax;
            this.puTicks = puTicks;
            this.puCooldown = puCooldown;
        }

        public static void encode(LightPacket m, FriendlyByteBuf b) {
            b.writeFloat(m.stamina);
            for (int i = 0; i < HeroData.SLOTS; i++) { b.writeVarInt(m.cd[i]); b.writeVarInt(m.cdMax[i]); }
            b.writeVarInt(m.puTicks);
            b.writeVarInt(m.puCooldown);
        }

        public static LightPacket decode(FriendlyByteBuf b) {
            float st = b.readFloat();
            int[] cd = new int[HeroData.SLOTS];
            int[] cdMax = new int[HeroData.SLOTS];
            for (int i = 0; i < HeroData.SLOTS; i++) { cd[i] = b.readVarInt(); cdMax[i] = b.readVarInt(); }
            return new LightPacket(st, cd, cdMax, b.readVarInt(), b.readVarInt());
        }

        public static void handle(LightPacket m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.onLight(m)));
            c.setPacketHandled(true);
        }
    }
}
