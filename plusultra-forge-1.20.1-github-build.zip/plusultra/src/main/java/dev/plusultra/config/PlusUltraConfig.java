package dev.plusultra.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class PlusUltraConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue AUTO_AWAKEN;
    public static final ForgeConfigSpec.BooleanValue PVP_ABILITIES;
    public static final ForgeConfigSpec.BooleanValue BLOCK_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULT;
    public static final ForgeConfigSpec.DoubleValue XP_MULT;
    public static final ForgeConfigSpec.DoubleValue REGEN_MULT;
    public static final ForgeConfigSpec.DoubleValue MISSION_MULT;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("general");
        AUTO_AWAKEN = b.comment("Give new players a random (non-legendary) quirk the first time they join.")
                .define("autoAwakenOnFirstJoin", true);
        PVP_ABILITIES = b.comment("Allow quirk abilities to hurt other players.")
                .define("pvpAbilities", true);
        BLOCK_DAMAGE = b.comment("Allow explosions / Decay to destroy blocks (respects mobGriefing for explosions).")
                .define("blockDamage", false);
        b.pop();
        b.push("balance");
        DAMAGE_MULT = b.comment("Global ability damage multiplier.").defineInRange("damageMultiplier", 1.0, 0.1, 10.0);
        XP_MULT = b.comment("Mastery XP multiplier.").defineInRange("masteryXpMultiplier", 1.0, 0.1, 20.0);
        REGEN_MULT = b.comment("Stamina regeneration multiplier.").defineInRange("staminaRegenMultiplier", 1.0, 0.1, 10.0);
        MISSION_MULT = b.comment("Mission reward multiplier.").defineInRange("missionRewardMultiplier", 1.0, 0.1, 10.0);
        b.pop();
        SPEC = b.build();
    }

    private PlusUltraConfig() {}
}
